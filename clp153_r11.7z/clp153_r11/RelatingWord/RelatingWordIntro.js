

var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrMc = []
var introTitle, introQuesText, introQHolder, introQues;
var introchoiceArr = [];
var introchoiceArr1 = [];
var TempIntroVal = 0
var pos1 = [250, 250, 875, 875]
var posi1 = [-250, -800, 1200, 1800]
var pos2 = [350, 600, 600, 350]

var ArrowXArr = [, 320, 930], FingXArr = [, 340, 960]
var ArrowYArr = [, 200, 460], FingYArr = [, 320, 560]

function commongameintro() {

    introArrow = arrow1.clone()
    container.parent.addChild(introArrow)
    introfingure = fingure.clone()
    container.parent.addChild(introfingure)
    // ///////////////////////////////////////Title//////////////////

    introTitle = Title.clone()
    container.parent.addChild(introTitle)
    introTitle.visible = true
    // //////////////////////////////////////////////Question Text//////////

    introQuesText = questiontext.clone()
    container.parent.addChild(introQuesText)
    introQuesText.visible = false


    // /////////////////////////////////////////choice/////////////////////

    for (i = 0; i < 2; i++) {
        introArrMc[i] = new createjs.MovieClip()
        container.parent.addChild(introArrMc[i])
        introArrMc[i].regX = introArrMc.regY = 0;
        introArrMc[i].visible = false;

        introchoiceArr[i] = choice1.clone();
        introchoiceArr[i].visible = false;
        introchoiceArr[i].scaleX = introchoiceArr[i].scaleY = 1;
        introchoiceArr[i].x = pos1[i]
        introchoiceArr[i].y = pos2[i]
        introchoiceArr[i].gotoAndStop(i)
        container.parent.addChild(introchoiceArr[i])

        introchoiceArr1[i] = choice2.clone();
        introchoiceArr1[i].visible = false;
        introchoiceArr1[i].scaleX = introchoiceArr1[i].scaleY = 1;
        introchoiceArr1[i].x = pos1[i + 2]
        introchoiceArr1[i].y = pos2[i + 2]
        introchoiceArr1[i].gotoAndStop(i)
        container.parent.addChild(introchoiceArr1[i]);
        // introArrMc[i].addChild(introchoiceArr1[i], introchoiceArr[i])
    }


    introQuesText.visible = true;
    introQuesText.alpha = 0;
    introQuesText.x = -425;
    introQuesText.y = 170;
    introQuesText.scaleX = introQuesText.scaleY = 1.2;

    introQuesText.gotoAndStop(0);
    createjs.Tween.get(introQuesText)
        .to({ x: 270, alpha: 1 }, 1000).call(handleComplete1_0);


}



function handleComplete1_0() {


    if (stopValue == 0) {
        removeGameIntro()
    }

    else {
        createjs.Tween.removeAllTweens()
        choiceTween()

    }

}



function choiceTween() {

    var tempVal = 100;


    for (i = 0; i < 2; i++) {

        ////////////////////////////////////////////////////////
        introchoiceArr[i].visible = true;
        introchoiceArr[i].alpha = 0;

        introchoiceArr1[i].visible = true;
        introchoiceArr1[i].alpha = 0;

        // console.log("..x.." + choiceArr[i].x);
        // console.log("...y." + choiceArr[i].y);
        // console.log("...1x." + choiceArr1[i].x);
        // console.log("..1y.." + choiceArr1[i].y);
        /////////////////////////////////////////////////////////////////////

        createjs.Tween.get(introchoiceArr[i])
            .to({ alpha: 1 }, 250)
            .to({ alpha: 1 }, 250)



        createjs.Tween.get(introchoiceArr1[i])
            .to({ alpha: 1 }, 250)
            .to({ alpha: 1 }, 250)


    }


    // for (i = 0; i < 2; i++) {
    //     introchoiceArr[i].visible = true;
    //     introchoiceArr[i].alpha = 1;
    //     introchoiceArr1[i].visible = true;
    //     introchoiceArr1[i].alpha = 1;
    //     introArrMc[i].visible = true;
    //     introArrMc[i].addChild(introchoiceArr[i],introchoiceArr1[i])

    //     introArrMc[i].timeline.addTween(createjs.Tween.get(introchoiceArr[i])   
    //     .to({ x: introchoiceArr[i].x-10 }, 39)
    //     .to({ x: introchoiceArr[i].x },40)
    //     .to({ x: introchoiceArr[i].x+10 }, 39)
    //     .to({ x: introchoiceArr[i].x, y: introchoiceArr[i].y },40)
    //      .wait(1))
    //      introArrMc[i].timeline.addTween(createjs.Tween.get(introchoiceArr1[i])   
    //      .to({ x: introchoiceArr1[i].x-10 }, 39)
    //      .to({ x: introchoiceArr1[i].x },40)
    //      .to({ x: introchoiceArr1[i].x+10 }, 39)
    //      .to({ x: introchoiceArr1[i].x, y: introchoiceArr1[i].y },40)
    //       .wait(1))
    // }  
    // if (i == 1) {
    //     createjs.Tween.get(introchoiceArr[i]).wait(tempVal)
    //     .to({x:posi1[i],alpha:1 }, 500, createjs.Ease.bounceOut)
    //     .to({x:pos1[i] ,visible: true, alpha: 1 }, 500, createjs.Ease.bounceOut).wait(200).call(handleComplete4_0);
    //     createjs.Tween.get(introchoiceArr1[i]).wait(tempVal)
    //     .to({x:posi1[i],alpha:1 }, 500, createjs.Ease.bounceOut)
    //     .to({x:pos1[i+2] ,visible: true, alpha: 1 }, 500, createjs.Ease.bounceOut).wait(200).call(handleComplete4_0);
    // }
    // else {
    //     createjs.Tween.get(introchoiceArr[i])
    //     .wait(tempVal)
    //     .to({x:posi1[i],alpha:1 }, 500, createjs.Ease.bounceOut)
    //     .to({x:pos1[i] ,visible: true, alpha: 1 }, 500, createjs.Ease.bounceOut)
    //     createjs.Tween.get(introchoiceArr1[i])
    //     .wait(tempVal)
    //     .to({x:posi1[i],alpha:1 }, 500, createjs.Ease.bounceOut)
    //     .to({x:pos1[i+2] ,visible: true, alpha: 1 }, 500, createjs.Ease.bounceOut)
    // }
    // tempVal += 100;
    setTimeout(handleComplete4_0, 3000);

}

function handleComplete4_0() {

    createjs.Tween.removeAllTweens()
    choiceMove()
}
function choiceMove() {
    TempIntroVal = 1
    for (i = 0; i < 2; i++) {
        if (i == 0) {
            createjs.Tween.get(introchoiceArr[i]).to({ visible: true, alpha: 1 }, 200).to({ visible: true, alpha: 1 }, 300)
            createjs.Tween.get(introchoiceArr1[i]).to({ visible: true, alpha: 1 }, 200).to({ visible: true, alpha: 1 }, 300)

        }

        else {
            createjs.Tween.get(introchoiceArr[i]).to({ visible: true, alpha: 1 }, 200).to({ visible: true, alpha: 1 }, 300).wait(500).to({ alpha: 0.5 })
            createjs.Tween.get(introchoiceArr1[i]).to({ visible: true, alpha: 1 }, 200).to({ visible: true, alpha: 1 }, 300).wait(500).to({ alpha: 0.5 })
        }
    }
    createjs.Tween.get(introchoiceArr[1]).wait(500).to({ alpha: 0.5 }, 100)


    createjs.Tween.get(introchoiceArr1[1]).wait(500).to({ alpha: 0.5 }, 100).wait(1000)
        .call(handleComplete5_0);

}



function handleComplete5_0() {
    createjs.Tween.removeAllTweens()
    setArrowTween()

}

function setArrowTween() {

    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introfingure.visible = false;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: ArrowYArr[TempIntroVal] + 10 }, 350)
            .to({ y: ArrowYArr[TempIntroVal] }, 350)
            .to({ y: ArrowYArr[TempIntroVal] + 10 }, 350).wait(400).call(this.onComplete1)
    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])

        if (TempIntroVal == 2) {
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).wait(200).call(this.onComplete2)
        }
        else {

            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).wait(200).call(handleComplete5_0)
        }

        TempIntroVal++;
    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);

    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()
    } else {
        setTimeout(setFingureTween, 200)
    }

}



this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()
    }

    else {
        console.log("setCallDelay  == stopValue")
        setTimeout(setCallDelay, 500)
    }

}

function setCallDelay() {

    createjs.Tween.removeAllTweens();
    clearInterval(removeIntraval)

    removeIntraval = 0

    setIntroCnt++

    console.log("check cnt = " + setIntroCnt)

    removeGameIntro()

    if (stopValue == 0) {

        console.log("setCallDelay  == stopValue")

        removeGameIntro()

    }

    else {

        commongameintro()

        if (setIntroCnt > 0) {

            isVisibleStartBtn()

        }

    }



}

function removeGameIntro() {



    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false

    container.parent.removeChild(introQuesText)
    introQuesText.visible = false

    for (i = 0; i < 2; i++) {
        container.parent.removeChild(introchoiceArr[i])
        introchoiceArr[i].visible = false;
        container.parent.removeChild(introchoiceArr1[i])
        introchoiceArr1[i].visible = false;

        container.parent.removeChild(introArrMc[i])
        introArrMc[i].visible = false;
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }




}

