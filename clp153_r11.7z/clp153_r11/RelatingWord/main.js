

///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////

var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var qscnt = -1
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var currentX, currentY

///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var cno = []
var choiceArr = []
var posArr = []
var choiceArr = [];
var choiceArr1 = [];
var clk;
var rand1 = [];
var rand2 = [];
var rand3 = [];
var rand4 = [];
var qno1 = [];
var choiceMcArr = [];
//register key functions

///////////////////////////////////////////////////////////////////

window.onload = function (e) {
    checkBrowserSupport();
}

///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    createLoader()
    createCanvasResize()
    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////
    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */
    assetsPath = "assets/";
    gameAssetsPath = "RelatingWord/";
    soundpath = "FA/"
    var success = createManifest();
    if (success == 1) {
        manifest.push(

            { id: "questiontext", src: questionTextPath + "RelatingWord-QT.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "ChoiceImages2.png" },

        )
        preloadAllAssets()
        stage.update();
    }
}

//====================================================DONE LOADING=================================================================//

function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;

    if (id == "questiontext") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("questiontext")],
            "frames": { "regX": 50, "height": 55, "count": 0, "regY": 50, "width": 720 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        questiontext = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(questiontext);
        questiontext.visible = false;
    }


    if (id == "choice1") {
        var spriteSheet4 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 95, "count": 0, "regY": 50, "width": 265 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet4);
        choice1.visible = false;
        container.parent.addChild(choice1);
    };

    if (id == "choice2") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 95, "count": 0, "regY": 50, "width": 265 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice2 = new createjs.Sprite(spriteSheet1);
        choice2.visible = false;
        container.parent.addChild(choice2);
    };

}



function tick(e) {

    stage.update();

}

/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////

function handleClick(e) {

    qno = between(0, 18);

    qno.splice(qno.indexOf(0), 1)
    qno.push(0)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();

    } else {

        //for db
        getdomainpath()
        //end
    }
}
function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questiontext);
    questiontext.visible = true;
    var posX = [250, 875];
    var posY = [300, 600, 600, 300]
    for (i = 0; i < choiceCnt; i++) {
        //////////////////////////////////////////////////
        choiceMcArr[i] = new createjs.MovieClip()
        container.parent.addChild(choiceMcArr[i])
        choiceMcArr[i].regX = choiceMcArr[i].regY = 0;
        //////////////////////////////////////////////////////
        choiceArr[i] = choice1.clone();
        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = true;
        choiceArr[i].name = i;
        choiceArr[i].x = posX[i];
        choiceArr[i].y = posY[i];
        ///////////////////////////////////////////////////////
        choiceArr1[i] = choice2.clone();
        container.parent.addChild(choiceArr1[i]);
        choiceArr1[i].visible = true;
        choiceArr1[i].name = i;
        choiceArr1[i].x = posX[i];
        choiceArr1[i].y = posY[i + 2];
        ///////////////////////////////////////////////////
        choiceMcArr[i].addChild(choiceArr[i], choiceArr1[i]);


    }

    if (isQuestionAllVariations) {
        createGameWiseQuestions()

        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        posType = [0, 1, 2, 0, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1, 2, 0, 1]

    } else {

        posArr = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        posType = [0, 1, 2, 0, 1, 2, 0, 1, 2, 1]
    }

    posArr.sort(randomSort)
    posType.sort(randomSort)

}

function helpDisable() {

    for (i = 0; i < choiceCnt; i++) {

        choiceArr[i].mouseEnabled = false;
        choiceArr1[i].mouseEnabled = false;

    }

}

function helpEnable() {

    for (i = 0; i < choiceCnt; i++) {

        choiceArr[i].mouseEnabled = true;
        choiceArr1[i].mouseEnabled = true;

    }

}

//=================================================================================================================================//

function pickques() {
    pauseTimer();
    tx = 0;
    cnt++;
    quesCnt++;
    qscnt++;
    chpos = [];
    attemptCnt = 0;
    currentObj = [];
    panelVisibleFn();
    clk = -1;
    //=================================================================================================================================//
    questiontext.visible = true;
    questiontext.alpha = 1
    questiontext.x = 450;
    questiontext.y = 170
    questiontext.gotoAndStop(qno[cnt])
    ///////////////////////////////////////
    for (i = 0; i < 19; i++) {

        cno[i] = i
    }
    cno.sort(randomSort)

    /////////////////////////////////////// 

    var rand1 = cno.indexOf(qno[cnt])
    console.log("cno///" + cno)
    cno.splice(rand1, 1)
    console.log("cno" + cno)

    for (i = 0; i < choiceCnt; i++) {

        choiceArr[i].visible = true;
        choiceArr[i].gotoAndStop(cno[i]);
        choiceArr[i].name = "ch" + i


        choiceArr1[i].visible = true;
        choiceArr1[i].gotoAndStop(cno[i]);
        choiceArr1[i].name = "ch1" + i
    }
    choiceArr[0].gotoAndStop(qno[cnt]);
    choiceArr1[0].gotoAndStop(qno[cnt]);

    ans1 = "ch0"
    ans2 = "ch10"
    /////////////////////////////////////////////////////////////

    if (posArr[cnt] == 0) {
        chpos.push(0, 1)
    }

    else {
        chpos.push(1, 0)
    }
    console.log("posType[cnt].." + posType[cnt])

    for (i = 0; i < choiceCnt; i++) {
        if (posType[cnt] == 0) {
            switch (i) {
                case 0:
                    choiceArr[chpos[i]].x = 250;
                    choiceArr[chpos[i]].y = 350;
                    choiceArr1[chpos[i]].x = 875;
                    choiceArr1[chpos[i]].y = 350;
                    break;
                case 1:
                    choiceArr[chpos[i]].x = 875;
                    choiceArr[chpos[i]].y = 600;
                    choiceArr1[chpos[i]].x = 250;
                    choiceArr1[chpos[i]].y = 600;
                    break;
            }

        }
        else if (posType[cnt] == 1) {
            switch (i) {
                case 0:
                    choiceArr[chpos[i]].x = 250;
                    choiceArr[chpos[i]].y = 350;
                    choiceArr1[chpos[i]].x = 250;
                    choiceArr1[chpos[i]].y = 600;
                    break;
                case 1:
                    choiceArr[chpos[i]].x = 875;
                    choiceArr[chpos[i]].y = 600;
                    choiceArr1[chpos[i]].x = 875;
                    choiceArr1[chpos[i]].y = 350;
                    break;
            }

        }
        else if (posType[cnt] == 2) {
            switch (i) {
                case 0:
                    choiceArr[chpos[i]].x = 250;
                    choiceArr[chpos[i]].y = 350;
                    choiceArr1[chpos[i]].x = 875;
                    choiceArr1[chpos[i]].y = 600;
                    break;
                case 1:
                    choiceArr[chpos[i]].x = 875;
                    choiceArr[chpos[i]].y = 350;
                    choiceArr1[chpos[i]].x = 250;
                    choiceArr1[chpos[i]].y = 600;
                    break;
            }



        }

        console.log("..x.." + choiceArr[chpos[i]].x);
        console.log("...y." + choiceArr[chpos[i]].y);
        console.log("...1x." + choiceArr1[chpos[i]].x);
        console.log("..1y.." + choiceArr1[chpos[i]].y);
    }

    createTween();

    createjs.Ticker.addEventListener("tick", tick);
    stage.update();

}

function createTween() {
    //////////////////////////////QuestionText////////////////////////////  

    questiontext.visible = true;
    questiontext.alpha = 0;
    questiontext.x = -425;
    questiontext.y = 170;
    questiontext.scaleX = questiontext.scaleY = 1.2;
    createjs.Tween.get(questiontext).wait(100)
        .to({ x: 270, alpha: 1 }, 200, createjs.Ease.bounceOut)
    showQuestion()
}
function showQuestion() {
    for (i = 0; i < 2; i++) {

        ////////////////////////////////////////////////////////
        choiceArr[chpos[i]].visible = true;
        choiceArr[chpos[i]].alpha = 0;

        choiceArr1[chpos[i]].visible = true;
        choiceArr1[chpos[i]].alpha = 0;

        console.log("..x.." + choiceArr[chpos[i]].x);
        console.log("...y." + choiceArr[chpos[i]].y);
        console.log("...1x." + choiceArr1[chpos[i]].x);
        console.log("..1y.." + choiceArr1[chpos[i]].y);
        /////////////////////////////////////////////////////////////////////

        createjs.Tween.get(choiceArr[chpos[i]])
            .to({ alpha: 1, x: choiceArr[chpos[i]].x - 10 }, 250)
            .to({ x: choiceArr[chpos[i]].x }, 250)



        createjs.Tween.get(choiceArr1[chpos[i]])
            .to({ alpha: 1, x: choiceArr1[chpos[i]].x - 10 }, 250)
            .to({ x: choiceArr1[chpos[i]].x, y: choiceArr1[chpos[i]].y }, 250)


    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2000)
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true
        choiceArr[i].cursor = "pointer";
        choiceArr1[i].addEventListener("click", answerSelected);
        choiceArr1[i].mouseEnabled = true
        choiceArr1[i].cursor = "pointer";
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    createjs.Tween.removeAllTweens();
    questiontext.visible = false

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].cursor = "pointer";
        choiceArr[i].alpha = 1
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr1[i].visible = false;
        choiceArr1[i].mouseEnabled = false;
        choiceArr1[i].cursor = "pointer";
        choiceArr1[i].alpha = 1
        choiceArr1[i].removeEventListener("click", answerSelected);
    }
}

function answerSelected(e) {
    clk++;
    e.preventDefault();
    e.currentTarget.cursor = "default";
    e.currentTarget.mouseEnabled = false

    uans = e.currentTarget.name;
    console.log("uans" + uans)
    gameResponseTimerStop();
    if (uans == ans1 || uans == ans2) {
        currentObj[clk] = e.currentTarget.name;
        e.currentTarget.alpha = .5

        if (clk == 1) {
            for (i = 0; i < 2; i++) {
                choiceArr[i].removeEventListener("click", answerSelected);
                choiceArr1[i].removeEventListener("click", answerSelected);
            }
            setTimeout(correct, 500)

        }
    }
    else {
        getValidation("wrong");
        disablechoices();
    }

}


function correct() {
    getValidation("correct");
    disablechoices();
}
