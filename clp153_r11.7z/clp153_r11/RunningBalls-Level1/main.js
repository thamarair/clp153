
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, question, circleOutline, circle1Outline, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q

var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES/////////////////////////////////////////////////////////
var currentX
var currentY, mask1, mask2, mask3, mask4, ball
var ballCnt, leftCnt, leftCnt1,rightCnt, rightCnt1,left,left1, right,right1, questionText1;
var rand3, valnum, colorCnt;
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var leftBalls = []
var rightBalls = []
var leftBalls1 = []
var rightBalls1 = []
var val = []
var leftColors = []
var rightColors = []
var leftColors1= []
var rightColors1 = []
var tweenMcArr1 = []
var tweenMcArr2 = []
var tweenMcArr3 = []
var tweenMcArr4 = []
var ballColor = ["yellow", "brown", "red", "green","blue","maroon","purple", "orange", "sandal", "dark green"]
var c1 = [2, 8, 3, 3, 2, 8, 5, 4, 2, 4]
var c2 = [6, 5, 5, 2, 4, 6, 3, 3, 4, 2]
var c3 = [4, 3, 7, 4, 6, 4, 1, 6, 6, 5]
var c4 = [3, 6, 2, 6, 5, 2, 7, 5, 4, 3]
var PosX1=[0,1155,0,1155];
var PosX2=[-10,1200,-10,1200];
var PosY1=[210,343,474,610];
// var ansVal=[2,1,3,4,3,4,3,2,1,2]
var ansVal=[1,0,2,3,2,3,2,1,0,1]

var introImg,introImg1
var choiceArr1=[];
var choiceArr2=[];

//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);


    createLoader()

    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "RunningBalls-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(

            { id: "chHolder", src: gameAssetsPath + "Holder.png" },
            { id: "balls", src: gameAssetsPath + "Balls.png" },
            { id: "ballsPipe", src: gameAssetsPath + "ballsPipe.png" },       
            { id: "questionText", src: questionTextPath + "RunningBalls-Level1-QT.png" },
            { id: "questionText1", src: questionTextPath + "RunningBalls-Level1-QT1.png" },
            { id: "questionText2", src: questionTextPath + "RunningBalls-Level1-QT2.png" },
			{ id: "introImg", src: questionTextPath + "Hint/RunningBalls-Level1-Hint.png" }
	
        )
        preloadAllAssets()
        stage.update();
    }
}
//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    console.log("get Id =" + id)
    if (id == "introImg") {

		introImg = new createjs.Bitmap(preload.getResult('introImg'));
		container.parent.addChild(introImg);
		introImg.visible = false;
    }
   
    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "questionText1") {
        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }
    if (id == "questionText2") {
        questionText2 = new createjs.Bitmap(preload.getResult('questionText2'));
        container.parent.addChild(questionText2);
        questionText2.visible = false;
    }
    

    if (id == "balls") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("balls")],
            "frames": { "regX": 50, "height": 80, "count": 0, "regY": 50, "width": 80 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        ball = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(ball);
        ball.visible = false;
        //			 
    }

    if (id == "ballsPipe") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("ballsPipe")],
            "frames": { "regX": 50, "height": 90, "count": 0, "regY": 50, "width": 230 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        ballsPipe = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(ballsPipe);
        ballsPipe.visible = false;
        //			 
    }

}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 9)
   
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() {
    interval = setInterval(countTime, 1000);
    container.parent.addChild(chHolder);
    chHolder.visible = false;
    container.parent.addChild(questionText);
    questionText.visible = false;
    questionText.x =0
    questionText.y = 0

    container.parent.addChild(questionText1);
    questionText1.visible = false;
    questionText1.x = 0
    questionText1.y = 0
    container.parent.addChild(questionText2);
    questionText2.visible = false;
    questionText2.x = 0
    questionText2.y = 0


for(i=0;i<4;i++)
{
    choiceArr1[i]=ballsPipe.clone();
    container.parent.addChild(choiceArr1[i])
    choiceArr1[i].x=PosX2[i];
    choiceArr1[i].y=PosY1[i];
    choiceArr1[i].name=i+1;
    choiceArr1[i].visible=false
    choiceArr1[i].gotoAndStop(i);
}

}
//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//==================================================================PICKQUES==========================================================================//
function pickques() {

    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    panelVisibleFn()
    rightColors = []
    leftColors = []
    rightColors1 = []
    leftColors1 = []
    val = []
    //=================================================================
    console.log(  "qno===" + qno[cnt])
  
    for(i=0;i<4;i++)
    {
    
        choiceArr1[i].visible=false
        choiceArr1[i].alpha=0
    }

    questionText.visible = false
  
    leftCnt = c1[qno[cnt]]
    leftCnt1 = c2[qno[cnt]]
    rightCnt = c3[qno[cnt]]
    rightCnt1 = c4[qno[cnt]]


    left = -1;
    right = -1;
    left1 = -1;
    right1 = -1;
    console.log(c1[qno[cnt]] + " ==leftCnt  " + c2[qno[cnt]] + " ==leftCnt 1  "+c3[qno[cnt]] + " ==rightCnt " + c4[qno[cnt]] + " ==rightCnt 1 " )
    createTween()
  

}
function callBallFn()
{

    clearTimeout(repTimeClearInterval)
    createjs.Tween.removeAllTweens();
    console.log("callBallFn")
    var cno=range(0,4)
    console.log("cno=="+cno)
    
  if(cno==0)  
  {
    
    if (left < leftCnt) {
        console.log("left=="+left)
    createLeftBalls();
    }
    else if (left==leftCnt)
    {
        console.log("both same left")
       callBallFn();
    }
  }
  else if(cno==1)
  {
    
    if (left1 < leftCnt1) {
    createLeftBalls1();
    }
    else if (left1==leftCnt1)
    {
        console.log("both same left1")
        callBallFn();
    }
  
  }
  else if(cno==2)
  {
    if (right < rightCnt) {
    createRightBalls();
    }
    else if (right==rightCnt)
    {
        console.log("both same right")
        callBallFn();
    }
  }
  else if(cno==3)
  {
    if (right1 < rightCnt1) {
    createRightBalls1();
    }
    else if (right1==rightCnt1)
   {
    console.log("both same right1")
    callBallFn();
     
   }
  }
 
}
function createLeftBalls() {
    left++;
    if (left < leftCnt) {
        var rand1 = range(0, 9)
        leftColors.push(rand1)
        leftBalls[left] = ball.clone();
        container.parent.addChild(leftBalls[left])
        leftBalls[left].visible = true;
        leftBalls[left].gotoAndStop(rand1)
        leftBalls[left].x = -10;
        leftBalls[left].y = 215
        leftBalls[left].scaleX = leftBalls[left].scaleY = 1
        console.log(rand1 + "    " )
        tweenMcArr1[left] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr1[left])
        for(i=0;i<4;i++)
        {          
            container.parent.addChild(choiceArr1[i])
        }
        tweenMcArr1[left].timeline.addTween(createjs.Tween.get(leftBalls[left]).to({ x: 0 }, 10).to({ x: 500 }, 12).to({ x: 750 }, 12).to({ x: 1000 }, 12)
            .to({ x: 1250 }, 12).to({ x: 1350 }, 12).wait(15));
        setTimeout(stopTween1, 2000);
    } else {
        showQues();
    }
}
function createLeftBalls1() {
    left1++;
    if (left1 < leftCnt1) {
        var rand1 = range(0, 9)
        leftColors1.push(rand1)
        leftBalls1[left1] = ball.clone();
        container.parent.addChild(leftBalls1[left1])
        leftBalls1[left1].visible = true;
        leftBalls1[left1].gotoAndStop(rand1)
        leftBalls1[left1].x = -10;
        leftBalls1[left1].y = 475
        leftBalls1[left1].scaleX = leftBalls1[left1].scaleY = 1
        console.log(rand1 + "    ")
        tweenMcArr3[left1] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr3[left1])
        for(i=0;i<4;i++)
        {          
            container.parent.addChild(choiceArr1[i])
        }
        tweenMcArr3[left1].timeline.addTween(createjs.Tween.get(leftBalls1[left1]).to({ x:0 }, 10).to({ x: 500 }, 12).to({ x: 750 }, 12).to({ x: 1000 }, 12)
            .to({ x: 1250 }, 12).to({ x: 1350 }, 12).wait(15));
        setTimeout(stopTween3, 2000);
    } else {

        showQues();
    }
}
function stopTween1() {
    tweenMcArr1[left].stop();
    leftBalls[left].visible = false;
    callBallFn();
        //  createLeftBalls()
}
function stopTween3() {
    tweenMcArr3[left1].stop();
    leftBalls1[left1].visible = false; 
    callBallFn();
    // createLeftBalls1()
}

function createRightBalls() {
    right++
    if (right < rightCnt) {
        var rand2 = range(0, 9)
        rightColors.push(rand2)
        rightBalls[right] = ball.clone();
        container.parent.addChild(rightBalls[right])
        rightBalls[right].visible = true
        rightBalls[right].gotoAndStop(rand2)
        rightBalls[right].x = 1300
        rightBalls[right].y = 345
        console.log(rand2 + "    " )

        rightBalls[right].scaleX = rightBalls[right].scaleY = 1
        tweenMcArr2[right] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr2[right])
        for(i=0;i<4;i++)
        {
           
            container.parent.addChild(choiceArr1[i])
        }
        tweenMcArr2[right].timeline.addTween(createjs.Tween.get(rightBalls[right])
        .to({ x: 1250 }, 10).to({ x: 750 }, 12).to({ x: 500 }, 12).to({ x: 250 }, 12)
        .to({ x: 0 }, 12).to({ x: -200 }, 12).wait(15));
        setTimeout(stopTween2, 2200);
    } else {
        showQues();
    }
}

function createRightBalls1() {
    right1++
    if (right1 < rightCnt1) {
        var rand2 = range(0, 9)
        rightColors1.push(rand2)
        rightBalls1[right1] = ball.clone();
        container.parent.addChild(rightBalls1[right1])
        rightBalls1[right1].visible = true
        rightBalls1[right1].gotoAndStop(rand2)
        rightBalls1[right1].x = 1300
        rightBalls1[right1].y = 610
        console.log(rand2 + "    ")

        rightBalls1[right1].scaleX = rightBalls1[right1].scaleY = 1
        tweenMcArr4[right1] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr4[right1])
        for(i=0;i<4;i++)
        {          
            container.parent.addChild(choiceArr1[i])
        }
        tweenMcArr4[right1].timeline.addTween(createjs.Tween.get(rightBalls1[right1])
        .to({ x: 1250 }, 10).to({ x: 750 }, 12).to({ x: 500 }, 12).to({ x: 250 }, 12)
        .to({ x: 0 }, 12).to({ x: -200 }, 12).wait(15));
        setTimeout(stopTween4, 2200);
    } else {
        showQues();
    }
}


function stopTween2() {
    tweenMcArr2[right].stop();
    rightBalls[right].visible = false
    callBallFn();
    // createRightBalls()
 
}
function stopTween4() {
    tweenMcArr4[right1].stop();
    rightBalls1[right1].visible = false;
    callBallFn();
    // createRightBalls1()

}
function showQues() {

    if (left == leftCnt && right == rightCnt&&left1 == leftCnt1 && right1 == rightCnt1) {
      
   
       ans = ansVal[qno[cnt]]
       console.log("condition achieved"+ans)
       enablechoices();

    }
    else  if (left == leftCnt)
    {
        callBallFn();
      
    }
    else  if (left1 == leftCnt1)
    {
        callBallFn();
      
    }
    else  if (right1 == rightCnt1)
    {
        callBallFn();
      
    }
    else {
        callBallFn();
        console.log("condition never achieved")
    }



}
//====================================================================CHOICE ENABLE/DISABLE==============================================================//
function enablechoices() {
    // questionText1.visible = false
    questionText.visible = false
    
    createTween1()
}
function createTween() {
   

    questionText.visible = true;
    questionText.alpha=0
    questionText.y = -1000;
    createjs.Tween.get(questionText).wait(100).to({alpha:1, y: 0 }, 500, createjs.Ease.bounceOut);

    chHolder.visible=true;
    chHolder.alpha=0;
    chHolder.y= -46;
    createjs.Tween.get(chHolder).wait(100).to({alpha:1}, 500, createjs.Ease.bounceOut);

    for(i=0;i<4;i++)
    {   
        choiceArr1[i].visible=true
        choiceArr1[i].alpha=0;

        createjs.Tween.get(choiceArr1[i])
        .wait(600)
        .to({x:PosX1[i],alpha:1}, 500, createjs.Ease.bounceOut);
    }
    repTimeClearInterval = setTimeout(callBallFn, 2500)
}


function createTween1() {
    if(qno[cnt]<5)
    {
       
    questionText1.visible = true;
    questionText1.alpha=0
    questionText1.y = -500;
    createjs.Tween.get(questionText1).wait(100).to({alpha:1, y: 0 }, 500, createjs.Ease.bounceOut);

    }
      else if(qno[cnt]>=5||qno[cnt]<10)
   {
    questionText2.visible = true;
    questionText2.alpha=0
    questionText2.y = -500;
    createjs.Tween.get(questionText2).wait(100).to({alpha:1, y: 0 }, 500, createjs.Ease.bounceOut);
   }
    
    repTimeClearInterval1 = setTimeout(AddListenerFn, 700)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval1)
    createjs.Tween.removeAllTweens();
    console.log("eventlisterneer")
  
        for (i = 0; i < 4; i++) {

            choiceArr1[i].mouseEnabled = true;
            choiceArr1[i].visible = true;
            choiceArr1[i].cursor = "pointer";        
            choiceArr1[i].name=i+1;
            choiceArr1[i].addEventListener("click", answerSelected)
        }
    


    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
      questionText.visible=false;
      questionText1.visible=false;
      questionText2.visible=false;
      ball.visible=false;
        for (i = 0; i < 4; i++) {
   
            choiceArr1[i].mouseEnabled = false;
            choiceArr1[i].cursor = "default";
            choiceArr1[i].visible = false;
            choiceArr1[i].removeEventListener("click", answerSelected)
        }
    }

//=================================================================ANSWER SELECTION=======================================================================//
function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    if (ans == uans) {
        currentX = e.currentTarget.x - 30
        currentY = e.currentTarget.y - 40
        e.currentTarget.visible = true;
        disableMouse()
        setTimeout(correct, 500)

    } else {
        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {
    for (i = 0; i < 4; i++) {
        
        choiceArr1[i].mouseEnabled = false
    }

}


