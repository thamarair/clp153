var introQues1, introQuestxt, introChoice1, introHolder, introChoice2, introChoice3, introChoice4, introClu1, introClu2, introClu3, introClu4, introHolder, introArrow, introfingure, introTitle;
var introChoice1TweenArr = []
var TempIntroVal;
var highlightTweenArr = []
var cluegotoArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introBand
var introQuestxtX = 636; introQuestxtY = 120;
var introQues1X = 630, introQues1Y = 280
var introChoice1X = 280, introChoice1Y = 620;
var introChoice2X = 500, introChoice2Y = 620;
var introChoice3X = 720, introChoice3Y = 620;
var introChoice4X = 940, introChoice4Y = 620;
var introClu1X = 485, introClu1Y = 490;
var introClu2X = 605, introClu2Y = 490;
var introClu3X = 725, introClu3Y = 490;
var introClu4X = 845, introClu4Y = 490;
var introArrowX = 210, introArrowY = 350;
var introfingureX = 220, introfingureY = 520;
var ArrowXArr = [, 380, 80, 222, 672, 822, 522, 972, 1122], FingXArr = [, 396, 111, 236, 681, 836, 536, 986, 1136]
var ArrowYArr = [, 470, 470, 470, 470, 470, 470, 470, 470], FingYArr = [, 585, 585, 585, 585, 585, 585, 585, 585]
var introclueArr = [];
var introchoiceArr = [];
function commongameintro() {
    introTitle = Title.clone();
    introQues1 = question.clone();
    introQuestxt = questionText.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introHolder = chHolderMC.clone();

    container.parent.addChild(introTitle);
    introTitle.visible = true;

    container.parent.addChild(introQuestxt);
    introQuestxt.visible = true;

    container.parent.addChild(introHolder);
    introHolder.visible = false;

    container.parent.addChild(introQues1);
    introQues1.gotoAndStop(2);
    introQues1.visible = false;
    introQues1.x = 390;
    introQues1.y = 355;



    for (i = 0; i < 8; i++) {
        introclueArr[i] = Answer.clone();
        container.parent.addChild(introclueArr[i]);
        introclueArr[i].gotoAndStop(26);
        introclueArr[i].visible = false;
        introclueArr[i].y = 250;
        introclueArr[i].scaleX = introclueArr[i].scaleY = .65;
        introclueArr[i].x = 328 + (i * 90) - 14;
    }

    var val = [3, 20, 4, 19, 2, 0, 14, 17]
    for (i = 0; i < 8; i++) {
        introchoiceArr[i] = choice1.clone()
        introchoiceArr[i].scaleX = introchoiceArr[i].scaleY = .8;
        introchoiceArr[i].visible = false;
        container.parent.addChild(introchoiceArr[i]);
        introchoiceArr[i].x = 77 + (i * 150);
        introchoiceArr[i].y = 620;
        introchoiceArr[i].gotoAndStop(val[i]);
    }


    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 1000).call(handleComplete1_1);


}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {

    introHolder.visible = true;
    introHolder.alpha = 0
    createjs.Tween.get(introHolder).wait(100).to({ alpha: 1 }, 300);

    introQues1.visible = true;
    introQues1.alpha = 0
    createjs.Tween.get(introQues1).wait(200).to({ alpha: 1 }, 500).call(handleComplete2_1);



}
function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    choiceTween()
}
function choiceTween() {
    for (i = 0; i < 8; i++) {
        introclueArr[i].visible = true;
        introclueArr[i].alpha = 0
        createjs.Tween.get(introclueArr[i]).wait(100)
            .to({ alpha: 1 }, 100)
    }


    var vali = 400
    for (i = 0; i < 8; i++) {
        introchoiceArr[i].y = 570, introchoiceArr[i].x = introchoiceArr[i].x + 10;
        introchoiceArr[i].visible = true;
        introchoiceArr[i].alpha = 0;
        if (i == 7) {
            createjs.Tween.get(introchoiceArr[i]).wait(200).to({ y: 600, scaleX: .8, scaleY: .8, alpha: 1 }, 500).call(handleComplete4_1);
        }
        else {
            createjs.Tween.get(introchoiceArr[i]).wait(200).to({ y: 600, scaleX: .8, scaleY: .8, alpha: 1 }, 500);
        }
        vali = vali + 150
    }

    TempIntroVal = 0;

}

function handleComplete4_1() {
    if (TempIntroVal == 0) { }
    else {
        // introClueArr[TempIntroVal].visible = true;
        // introClueArr[TempIntroVal].gotoAndStop(cluegotoArr[TempIntroVal])
    }

    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    TempIntroVal++;

    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introfingure.visible = false;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: ArrowYArr[TempIntroVal] + 10 }, 100).to({ y: ArrowYArr[TempIntroVal] }, 100).to({ y: ArrowYArr[TempIntroVal] + 10 }, 100)
            .to({ y: ArrowYArr[TempIntroVal] }, 100).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        if (TempIntroVal == 8) {
            introclueArr[7].gotoAndStop(17);
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 300).to({ x: FingXArr[TempIntroVal] - 15 }, 300)
                .to({ x: FingXArr[TempIntroVal] }, 300).to({ x: FingXArr[TempIntroVal] - 15 }, 300).wait(200).call(this.onComplete2)
        }
        else {
            if(TempIntroVal == 1){
                introclueArr[0].gotoAndStop(4);
            }
            if(TempIntroVal == 2){
                introclueArr[1].gotoAndStop(3);
            }
            if(TempIntroVal == 3){
                introclueArr[2].gotoAndStop(20);
            }
            if(TempIntroVal == 4){
                introclueArr[3].gotoAndStop(2);
            }
            if(TempIntroVal == 5){
                introclueArr[4].gotoAndStop(0);
            }
            if(TempIntroVal == 6){
                introclueArr[5].gotoAndStop(19);
            }
            if(TempIntroVal == 7){
                introclueArr[6].gotoAndStop(14);
            }
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 100).to({ x: FingXArr[TempIntroVal] - 15 }, 100)
                .to({ x: FingXArr[TempIntroVal] }, 100).to({ x: FingXArr[TempIntroVal] - 15 }, 100).wait(200).call(handleComplete4_1)
        }


    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {

        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {

        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();

    // container.parent.removeChild(introTitle)
    // introTitle.visible = false;
    container.parent.removeChild(introArrow)
    introArrow.visible = false;
    container.parent.removeChild(introfingure)
    introfingure.visible = false;
    
    container.parent.removeChild(introQuestxt);
    introQuestxt.visible = false;

    container.parent.removeChild(introHolder);
    introHolder.visible = false;

    container.parent.removeChild(introQues1);
    introQues1.visible = false;

    for (i = 0; i < 8; i++) {
        container.parent.removeChild(introclueArr[i]);
        introclueArr[i].gotoAndStop(26);
    }

    for (i = 0; i < 8; i++) {
        container.parent.removeChild(introchoiceArr[i]);
        introchoiceArr[i].visible = false;
    }

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}