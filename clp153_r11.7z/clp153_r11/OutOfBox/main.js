
var messageField;		//Message display field
var assets = [];
var currentObj = []
var btnPadding = 100
var cnt = -1, qscnt = -1, ncnt = -1, ncnt1 = 0, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, questionCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, choice5, choice6, choice7, choice8, choice9, choice10, qChoiceCnt = 4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, ch = 0, n = 0, chHolderMc, btnImagesMc, qHolderMc, qCnt = -1, clk = -1;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var isBgSound = true;
var isEffSound = true;
var isOlderBrowser = false;
var isLandOrientation = false;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var queVal
var loadProgressLabel, progresPrecentage, loaderWidth;
var qno=[]
var question;
var quesArr=[];
var choiceArr=[]
var posArr=[]
var typeArr=[]
var chpos = [];
var cno=[];
var rand;
var posx = [];
var posy = [];
var pos=[]
var queNo
var btnX = [335,457,580,700,823,335,457,580,700,823,335,457,580,700,823];
var btnY = [188, 188, 188,188,188, 295,295,295,295,295,395,395,395,395,395];

///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader()
    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "OutOfBox/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
           
            { id: "questionText", src: questionTextPath + "OutOfBox-QT.png" },
            { id: "Holder", src: gameAssetsPath + "Holder.png" },         
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "question", src: gameAssetsPath + "question.png" }
          


        )
        preloadAllAssets()
        stage.update();
    }
}

//=================================================================DONE LOADING=================================================================// 
function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

    if (id == "Holder") {
        Holder = new createjs.Bitmap(preload.getResult('Holder'));
        container.parent.addChild(Holder);
        Holder.visible = false;
    }  
   
  
    if (id == "choice1") { 
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 0, "height": 160, "count": 0, "regY": 0, "width": 160 }
        });
        choice1= new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;
    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("question")],
            "frames": { "regX": 0, "height": 100, "count": 0, "regY": 0, "width": 120 }
        });
        question= new createjs.Sprite(spriteSheet1);      
        container.parent.addChild(question);
        question.visible =false
    
    }
       
 

}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno=between(0,15)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() { 
  
     
    container.parent.addChild(questionText);
        questionText.x = 0
        questionText.y = 0
        questionText.visible = false
  
    container.parent.addChild(Holder);    
    Holder.visible = false;
    Holder.x = Holder.x
    Holder.y = Holder.y
    Holder.scaleX = Holder.scaleY = 1
   
    
    for (i = 0; i < 15; i++) {
           
        quesArr[i] = question.clone();
        container.parent.addChild(quesArr[i]);
        quesArr[i].visible = false;
        quesArr[i].x=btnX[i];
        quesArr[i].y=btnY[i];
        quesArr[i].gotoAndStop(i)
        quesArr[i].scaleX=quesArr[i].scaleY=1
         }




var posX=[305,560,817]
var posY=[537,537,537]
for (i = 0; i <choiceCnt; i++) {
       
        choiceArr[i] = choice1.clone();
        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = false;
        choiceArr[i].x=posX[i];
        choiceArr[i].y=posY[i];
        choiceArr[i].gotoAndStop(i)
        choiceArr[i].name=i
        choiceArr[i].scaleX=choiceArr[i].scaleY=1
		console.log("choiceArr[i]///" + choiceArr[i])
 
        posx = choiceArr[i].x;
        posy = choiceArr[i].y;
        // chPos.push({ posx: choiceArr[i].x, posy: choiceArr[i].y })
        chpos.push({ posx: choiceArr[i].x, posy: choiceArr[i].y });
       
           }
           if (isQuestionAllVariations) {
            
            posArr = [0, 1,2 ,0, 1,2, 0,1,2,0, 1,2]
            
        } else {
            
            posArr = [0, 1,2 ,0, 1,2, 0,1,2,0]
           
        }
    
        posArr.sort(randomSort)
    }

function helpDisable() {
    for (i =0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    pauseTimer()
    tx = 0;     
    cnt++;
    qscnt++;
    quesCnt++;  
    panelVisibleFn();
    // 
    pos=[]
    for (i = 0; i < 16; i++) {
      
        cno[i] =i
    }
    cno.sort(randomSort)

   
var qno1=between(0,15)

console.log("qno1==="+qno1); 
qno1.splice(qno1.indexOf(15), 1)
console.log("qno1.length" + qno1.length)
////////////////////////////////////////

 rand= range(0,15);
var ansVal1 = cno.indexOf(qno1[rand])
console.log("cno///" + cno)
console.log("cno.length///" + cno.length)
cno.splice(ansVal1, 1)
cno.splice(qno1.indexOf(15), 1)
console.log("ansVal1" + ansVal1)
console.log("cno000" + cno)
//console.log("qno1.indexOf(15)" + qno1.indexOf(15), 1)
console.log("cno.length000" + cno.length)
/////////////////////////////////////////
    questionText.visible = false;  
    Holder.visible = false;
    console.log("rand///" + rand) 
 for (i = 0; i < 15; i++) {
        quesArr[i].visible = false
        quesArr[i].gotoAndStop(qno1[i])         
    }
    quesArr[rand].gotoAndStop(16) 
   for (i = 0; i <choiceCnt; i++) {
            
        choiceArr[i].visible = false;
        choiceArr[i].gotoAndStop(cno[i])
        choiceArr[i].name=i
		 console.log("cno[i][i]------" + cno[i])

           }

           choiceArr[0].gotoAndStop(qno1[rand])
        if (posArr[cnt] == 0) {
            pos.push(0, 1,2)
        }
         else if (posArr[cnt] == 1) {
            pos.push(1,2, 0)
        }
        else{
            pos.push(2,0,1)
        }
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].x = chpos[pos[i]].posx;
            choiceArr[i].y = chpos[pos[i]].posy;
        }
  

        ans=0
    
     CreateTween()
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}



function CreateTween() {
//     ////////////////////////////////questiontext////////////////////////////
    questionText.visible = true;
    questionText.alpha = 0;
    questionText.x = -100  
     
    createjs.Tween.get(questionText).wait(200)
        .to({x:0, alpha: 1 },300)

           Holder.visible = true;
           Holder.alpha = 0;
           createjs.Tween.get(Holder).wait(200)
        .to({ alpha: 1 },300)
    /////////////////////////choice image tween////////////////////

 var tempval = 500         
    for (i = 0; i < 15; i++) {
                quesArr[i].visible = true;
                quesArr[i].alpha = 0               
                createjs.Tween.get(quesArr[i]).wait(tempval)
                .to({  alpha: 1 }, 250)              
     }             
                
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[pos[i]].visible = true;
        choiceArr[pos[i]].alpha = 0;
        choiceArr[i].scaleX = choiceArr[i].scaleY = 1
		// console.log("choiceArr[i]///" + choiceArr[i])
		// console.log(" choiceArr[pos[i]]///" +  choiceArr[pos[i]])
      
        createjs.Tween.get(choiceArr[pos[i]]).wait(1000)
            .to({  alpha: 1 }, 500)
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2000)
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true
        choiceArr[i].visible = true;
        choiceArr[i].cursor = "pointer"
        choiceArr[i].alpha = 1;
        choiceArr[i].id = i
        choiceArr[i].name = i
        // choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].addEventListener("pressmove", onObjectDownHandler)
        choiceArr[i].addEventListener("pressup", getDragUp)
    }

    console.log("eventlisterneer")
    for (i = 0; i < 15; i++) {      

        quesArr[i].visible=true;
       
        quesArr[i].isDrag = false; 
  
    }
    quesArr[rand].id = rand;

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}

function onObjectDownHandler(evt) {
    var p = evt.currentTarget.parent.globalToLocal(evt.stageX, evt.stageY);
    container.parent.addChild(evt.currentTarget)
    evt.currentTarget.x = p.x-80;
    evt.currentTarget.y = p.y-80;
        stage.update()
    

}
function getDragUp(evt) {
    var setDropTarget;
    for (i = 0; i < choiceCnt; i++) {
        var p = quesArr[rand].globalToLocal(evt.stageX, evt.stageY);
        if(quesArr[rand].hitTest(p.x, p.y) && quesArr[i].isDrag == false)
         {
            setDropTarget =quesArr[rand]
            queVal = rand;
            quesArr[rand].isDrag = true;
           console.log("SetDropTarget"+setDropTarget); 
        } else {
            // console.log("error...")
        }
    }
       
    getDragObj = evt.currentTarget
    container.parent.addChild(getDragObj)
    // ans = evt.currentTarget.name;
    queNo = evt.currentTarget.id;
    objPos1 = chpos[pos[queNo]].posx
    objPos2 = chpos[pos[queNo]].posy
    if (intersect(evt.currentTarget, setDropTarget)) {
        getDragObj.mouseEnabled = false;
        getDragObj.visible = true;
        getDragObj.cursor = "default";
        getDragObj.x = setDropTarget.x;
        getDragObj.y = setDropTarget.y-15
        uans = setDropTarget.name;
        console.log("uans==" + uans)
        answerSelected(evt)
        stage.update(evt)
    }
    else {
        getDragObj.x = objPos1;
        getDragObj.y = objPos2;
    }

}

function intersect(obj1, obj2) {
    if (obj2 == null) {
        getDragObj.x = objPos1;
        getDragObj.y = objPos2;
    } else {
        var objBounds1 = obj1.getTransformedBounds()
        var objBounds2 = obj2.getTransformedBounds()
        if (objBounds1.intersects(objBounds2)) {
            return true;
        } else {
            return false;
        }
    }
}

function disablechoices() {
    createjs.Tween.removeAllTweens();
    Holder.visible = false;
    questionText.visible = false
    question.visible = false;
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;   
        choiceArr[i].removeEventListener("pressmove", onObjectDownHandler)
        choiceArr[i].removeEventListener("pressup", getDragUp)
    }
    for (i = 0; i < 15; i++) {
       
        quesArr[i].visible = false;
        quesArr[i].mouseEnabled=false;
        quesArr[i].alpha=0
         
    }
}
//=================================================================ANSWER SELECTION=======================================================================//

function answerSelected(e) {
    e.preventDefault();
     uans = e.currentTarget.name;
     gameResponseTimerStop();
     console.log(ans + " =correct= " + uans)
     if (ans == uans) {
         e.currentTarget.removeEventListener("click", answerSelected)
         for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].mouseEnabled = false;
         }
         choiceArr[queNo].visible = true;
         choiceArr[queNo].scaleX = choiceArr[queNo].scaleY = .8;
         quesArr[queVal].visible = false;
         quesArr[queVal].removeEventListener("click", answerSelected);        
        setTimeout(correctFn,1000)
 
     }
     else {
         for (i = 0; i < choiceCnt; i++) {
             choiceArr[i].visible = false;
             choiceArr[i].mouseEnabled = false;
         }
         getValidation("wrong");
         disablechoices();
     }
 
 }
 function correctFn()
 {
     getValidation("correct");
     disablechoices();
 }
 
 
 
 