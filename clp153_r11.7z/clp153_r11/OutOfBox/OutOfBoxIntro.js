var introArrow, introfingure, introTitle, introHolder,introquestionText;
var introChoiceArr=[];
var introChoice=[];
var highlightTweenArr = []
var setIntroCnt = 0;
var removeIntraval = 0, introCount = -1;
var introArrowX = 610, introArrowY = 480;
var introfingureX = 620, introfingureY = 600;
var introbtnX = [335,457,580,700,823,335,457,580,700,823,335,457,580,700,823];
var introbtnY =  [188, 188, 188,188,188, 295,295,295,295,295,395,395,395,395,395];
var intPosX = [305,560,817]
var intPosY=[537,537,537]
function commongameintro() {

    introTitle = Title.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introHolder = Holder.clone();
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    introquestionText=questionText.clone();

    container.parent.addChild(introquestionText)
    introHolder.visible = false;
    container.parent.addChild(introHolder)
    introHolder.visible = false;
  
    for (i = 0; i < 3; i++) {
        introChoice[i] = choice1.clone()
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false;
        introChoice[i].x = intPosX[i];
        introChoice[i].scaleX = introChoice[i].scaleY = 1;
        introChoice[i].y = intPosY[i]
        introChoice[i].gotoAndStop(i);
    }
    introChoice[1].gotoAndStop(6)
    for(i=0;i<15;i++)
        {
            introChoiceArr[i]=question.clone();
            container.parent.addChild(introChoiceArr[i])
            introChoiceArr[i].visible = false;
            introChoiceArr[i].x = introbtnX[i];
            introChoiceArr[i].y = introbtnY[i];
            introChoiceArr[i].gotoAndStop(i);
        }
        introChoiceArr[6].gotoAndStop(16)
          
    introquestionText.alpha = 0;
    introquestionText.visible = true
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 500).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    introHolder.visible = true;
    introHolder.alpha=0
    introHolder.x=-400
    createjs.Tween.get(introHolder).wait(100).to({ x:0,alpha:1}, 400, createjs.Ease.bounceOut)
   .call(handleComplete2_0); 
            }

 function handleComplete2_0() {
     if (stopValue == 0) {
                    removeGameIntro()
                }

     else {
                    choiceTween();
         }
            }

 function choiceTween()
     {
                
        for(i=0;i<15;i++)
        {
           
            introChoiceArr[i].visible = true;
            introChoiceArr[i].alpha=0;
            introChoiceArr[i].x=introbtnX[i]-10
            if(i==14)
            {
                createjs.Tween.get(introChoiceArr[i]).wait(200).to({ alpha:1,x:introbtnX[i],scaleX: .9, scaleY: .9 }, 250)
                .to({ scaleX: 1, scaleY: 1 }, 500).wait(250)
                .call(handleComplete2_1);
            }
            else{
                createjs.Tween.get(introChoiceArr[i]).wait(200).to({ alpha:1,x:introbtnX[i],scaleX: .9, scaleY: .9 }, 250)
                .to({ scaleX: 1, scaleY: 1 }, 250).wait(100)
            }
        
        }
            }
function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh();
    }
}
function introCh() {
 
    
        for (i = 0; i < 3; i++) {
            introChoice[i].visible = true
            introChoice[i].alpha = 0
            if (i == 2) {
                createjs.Tween.get(introChoice[i]).to({ visible: true, alpha: 1 }, 200)
                .to({ visible: true, alpha: 1 }, 300)
                .wait(500)
                .call(handleComplete3_1);
    
            }
    
            else {
                createjs.Tween.get(introChoice[i])
                .to({ visible: true, alpha: 1 }, 200)
                .to({ visible: true, alpha: 1 }, 300)
                .wait(500);
            }
        }

    
       
}
function handleComplete3_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh1()
        // setArrowTween();
    }
}
function introCh1() {
    
       createjs.Tween.get(introChoice[1]).wait(200)
       .to({ scaleX: .9, scaleY: .9 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        .to({ scaleX: .9, scaleY: .9 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        .wait(500).call(handleComplete4_1);
       

    }
  
    
    function handleComplete4_1() {
        createjs.Tween.removeAllTweens();
        setArrowTween()
    }
    function setArrowTween() {
        if (stopValue == 0) {
            console.log("setArrowTween  == stopValue")
            removeGameIntro()
        }
        else {
           
            container.parent.addChild(introArrow);      
            introArrow.visible = true;
            introfingure.visible = false;
            introArrow.alpha=1
            introArrow.x = introArrowX;
            introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
        .to({ y: introArrowY + 10 }, 350)
        .to({ y: introArrowY }, 350)
        .to({ y: introArrowY + 10 }, 350)
                .call(this.onComplete1)
    
            }  
      
    }
    
    function setFingureTween() {
          
        if (stopValue == 0) {
            console.log("setFingureTween  == stopValue")
            removeGameIntro()
    
        }
        else {
    
            container.parent.removeChild(introArrow);
            introArrow.visible = false;
            container.parent.addChild(introfingure); 
            introfingure.visible = true;
            introfingure.x = introfingureX;
            introfingure.y = introfingureY;
            // highlightTweenArr[1] = new createjs.MovieClip()
            // container.parent.addChild(highlightTweenArr[1])
            
            // highlightTweenArr[1] = createjs.Tween.get(introfingure)
            // .to({ x: introfingureX }, 350)
            // .to({ x: introfingureX - 15 }, 350)
            // .to({ x: introfingureX }, 350)
            // .to({ x: introfingureX - 15 }, 350)
            //         .wait(200).call(onComplete2);  
                    createjs.Tween.get(introfingure).wait(100)
                    .to({ x: 480, y: 300 }, 500);
                    introChoiceArr[6].visible=false;
                createjs.Tween.get(introChoice[1]).wait(100)
                    .to({ scaleX: .85, scaleY: .85, x: 450, y: 270 }, 500).wait(500).call(onComplete2);                 
                    
            }
    
    
    }
    this.onComplete1 = function (e) {
        createjs.Tween.removeAllTweens();

        if (highlightTweenArr[0]) {
            console.log("onComplete1")
            container.parent.removeChild(highlightTweenArr[0]);
        }

        container.parent.removeChild(introArrow);
        if (stopValue == 0) {
            console.log("onComplete1  == stopValue")
            removeGameIntro()
    
        } else {
            setTimeout(setFingureTween, 200)
           }
        
    }
    
    this.onComplete2 = function (e) {
        createjs.Tween.removeAllTweens();
    
      
        if (highlightTweenArr[1]) {
            console.log("onComplete2")
            container.parent.removeChild(highlightTweenArr[1]);
        }
   
        container.parent.removeChild(introfingure);
        introfingure.visible = false;
    
        if (stopValue == 0) {
            console.log("onComplete2  == stopValue")
            removeGameIntro()
    
        }
        else {
                
                setTimeout(setCallDelay, 1000)
            
        }
    
    
    }
    function setCallDelay() {
        clearInterval(removeIntraval)
        removeIntraval = 0
        setIntroCnt++
        console.log("check cnt = " + setIntroCnt)
        removeGameIntro()
        if (stopValue == 0) {
            console.log("setCallDelay  == stopValue")
            removeGameIntro()
        }
        else {
            commongameintro()
            if (setIntroCnt > 0) {
                isVisibleStartBtn()
            }
        }
    
    }
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow);
    introArrow.visible = false;
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    // container.parent.removeChild(introTitle);
    // introTitle.visible = false;
    container.parent.removeChild(introquestionText);
    introquestionText.visible = false;
    container.parent.removeChild(introHolder);
    introHolder.visible = false;

    for (i = 0; i < 3; i++) {
       
        container.parent.removeChild(introChoice[i])
        introChoice[i].visible = false;
    }

     for(i=0;i<15;i++)
     {         
        container.parent.removeChild(introChoiceArr[i]);
        introChoiceArr[i].visible = false;
     }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}

