var introQues1, introTitle, introQuestxt, introHolder, introArrow, introfingure;
var introCircle = [], introCircle1 = []
var introChoice = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var TempIntroVal=0
var ArrowXArr = [,787, 617], FingXArr = [,810, 640]
var ArrowYArr = [,490, 145], FingYArr = [,600, 255]
var Imgx = [347, 525, 700, 878,1055, 347, 525, 700, 878,1055,347, 525, 700, 878,1055]
var Imgy = [265, 265, 265, 265,265, 435, 435,435, 435, 435, 608, 608, 608, 608,608]

// var cirX = [467,820,650,290,467];
// var cirX1= [820,467,290,650,820]
// var cirY = [210,210,210,380,380];
// var cirY1= [380,550,550,550,550]
function commongameintro() {

    introTitle = Title.clone();
    introTitle.visible = true;
    container.parent.addChild(introTitle)

    introQuestxt = questionText.clone()
    introHolder = Holder.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    introCircle = introHint.clone();
    container.parent.addChild(introHolder)
    introHolder.visible = false;
    introHolder.y = 0
    introHolder.x = -210
    container.parent.addChild(introQuestxt)
    introQuestxt.visible = true;
    vno = [0, 1, 13, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    for (i = 1; i <= 15; i++) {
        introChoice[i] = choice1.clone();
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false;
        introChoice[i].gotoAndStop(vno[i - 1])
        introChoice[i].alpha = 0
        introChoice[i].scaleX = introChoice[i].scaleY = 1

    }
  
         introCircle = introHint.clone();
        container.parent.addChild(introCircle)
        introCircle.visible = false
        introCircle.x = 735
        introCircle.y = 550

        introCircle1 = introHint1.clone();
        container.parent.addChild(introCircle1)
        introCircle1.visible = false
        introCircle1.x = 560
        introCircle1.y = 210


    introQuestxt.alpha = 0;
    introQuestxt.x = -290
    introQuestxt.y = 0
    createjs.Tween.get(introQuestxt).wait(500)
        .to({ x: 0, alpha: 1 }, 500).call(handleComplete1_1);


}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        HolderTween()
    }
}

function HolderTween() {
    introHolder.visible = true
    introHolder.alpha = 0;
    introHolder.x = -210
    introHolder.y = 25
    createjs.Tween.get(introHolder).wait(500)
        .to({ alpha: 1, y: 25, x: 0 }, 500)
        .call(handleComplete1_2);

}
function handleComplete1_2() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween()
    }
}
function choiceTween() {
    var val = 250
   
    for (i = 1; i <= 15; i++) {
        introChoice[i].visible = true
        introChoice[i].alpha = 0
        introChoice[i].x = Imgx[i - 1]-90
        introChoice[i].y = Imgy[i - 1] -1000
  

        if (i == 15) {
            createjs.Tween.get(introChoice[i]).wait(val)
                .to({ y:Imgy[i - 1] , alpha: 1}, 500).wait(1000)
                .call(handleComplete3_1)
        }
        else {
            createjs.Tween.get(introChoice[i]).wait(val)
                .to({ y:Imgy[i - 1] , alpha: 1 }, 500)
        }
        val = val + 100
    }
 
  }
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    HintTween()
}
function HintTween() {

var val=200


  createjs.Tween.get(introCircle).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500)

createjs.Tween.get(introCircle1).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500).wait(1000)
 .call(handleComplete3_2)

}
function handleComplete3_2() {
    createjs.Tween.removeAllTweens();
   
        introCircle.visible = false;      
        introCircle1.visible = false;
  
        
    answerTween()
}
function answerTween() {
    TempIntroVal=1
    createjs.Tween.get(introChoice[3])
        .to({ visible: true, alpha: 1 }, 500)
        .to({ scaleX: .85, scaleY: .85 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        .to({ scaleX: .85, scaleY: .85 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        createjs.Tween.get(introChoice[14])
        .to({ visible: true, alpha: 1 }, 500)
        .to({ scaleX: .85, scaleY: .85 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        .to({ scaleX: .85, scaleY: .85 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500)
        .call(handleComplete3_3)
}

function handleComplete3_3() {
    createjs.Tween.removeAllTweens();
    setTimeout(setArrowTween, 500)
}

function setArrowTween() {
 
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introfingure.visible = false;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: ArrowYArr[TempIntroVal] + 10 }, 350)
            .to({ y: ArrowYArr[TempIntroVal] }, 350)
            .to({ y: ArrowYArr[TempIntroVal] + 10 }, 350).wait(400).call(this.onComplete1)
    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure); 
        introfingure.visible = true;
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])

        if (TempIntroVal == 2) {
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).wait(200).call(this.onComplete2)
        }
        else {

            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).wait(200).call(handleComplete3_3)
        }

        TempIntroVal++;
    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {

        setTimeout(setCallDelay, 250)
    }

}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {

    createjs.Tween.removeAllTweens();
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false

    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false
    for (i = 1; i <= 15; i++) {
        container.parent.removeChild(introChoice[i])
        introChoice[i].visible = false

    }


        container.parent.removeChild(introCircle)
        introCircle.visible = false
        container.parent.removeChild(introCircle1)
        introCircle1.visible = false


    container.parent.removeChild(introHolder)
    introHolder.visible = false;

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }

}