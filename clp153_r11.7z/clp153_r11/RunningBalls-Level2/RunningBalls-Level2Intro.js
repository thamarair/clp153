var introTitle, introQuestxt, introQues, introArrow, introfingure, introHolder;
var introPipeArr = []

var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 50, introArrowY = 280;
var introfingureX = 80, introfingureY = 365;
var introBall = [];
var introPosX1 = [0, 0, 0, 1155, 1155, 1155];
var introPosY1 = [238, 408, 578, 318, 488, 658];
function commongameintro() {
    introTitle = Title.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introHolder = iHolder.clone();
    iball = ball.clone();
    introQuestxt = questionText.clone();
    introQuestxt1 = questionText1.clone();

    container.parent.addChild(introTitle);
    introTitle.visible = true;

    container.parent.addChild(introQuestxt1);
    introQuestxt1.visible = false;

    container.parent.addChild(introHolder)
    introHolder.visible = false;
    introHolder.scaleY = 1;
    introHolder.y = introHolder.y + 50;

    container.parent.addChild(introImg);
    introImg.visible = false;
    introImg.scaleX = introImg.scaleY = 1.5
    introImg.regX = introImg.regY = 50;
    introImg.y = 250;
    introImg.x = 420;

    for (i = 0; i < 10; i++) {
        introBall[i] = iball.clone()
        container.parent.addChild(introBall[i])
        introBall[i].visible = false;
        introBall[i].scaleX = introBall[i].scaleY = .9
    }

    container.parent.addChild(introQuestxt);
    introQuestxt.visible = true;
    introQuestxt.x = 0
    introQuestxt.y = 0


    for (i = 0; i < 6; i++) {
        introPipeArr[i] = ballsPipe.clone();
        container.parent.addChild(introPipeArr[i]);
        introPipeArr[i].visible = false;
        introPipeArr[i].x = introPosX1[i];
        introPipeArr[i].y = introPosY1[i];
        introPipeArr[i].gotoAndStop(i);
        introPipeArr[i].scaleY = .95;
    }


    introQuestxt.visible = true;
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh()
    }
    // removeGameIntro()
}
function introCh() {
    introHolder.visible = true;
    createjs.Tween.get(introHolder).to({ alpha: 1 }, 500);
    for (i = 0; i < 6; i++) {
        introPipeArr[i].visible = true;
        introPipeArr[i].alpha = 0;
        createjs.Tween.get(introPipeArr[i]).to({ alpha: 1 }, 500)

    }

    introImg.visible = true;
    createjs.Tween.get(introImg).wait(500).to({ alpha: 1, scaleX: 1.6, scaleY: 1.6 }, 1000)
        .to({ scaleX: 1.5, scaleY: 1.5 }, 1000).to({ alpha: 1, scaleX: 1.6, scaleY: 1.6 }, 1000)
        .to({ scaleX: 1.5, scaleY: 1.5 }, 1000).wait(500).call(handleComplete2_1);
}

function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introCh1()
    }
}
function introCh1() {

    createjs.Tween.get(introImg).to({ alpha: 1, scaleX: 1, scaleY: 1, x: 420, y: 250 }, 500)
        .to({ scaleX: .9, scaleY: .9, y: 540, x: 510 }, 500).wait(500).call(handleComplete5_1);


}
function handleComplete5_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        quesTween()
    }
}
function quesTween() {


    var temp2 = 200;
    for (i = 0; i < 10; i++) {

        introBall[i].visible = true;
        if (i == 0) {
            console.log("i====" + i)
            introBall[i].gotoAndStop(2);
            introBall[i].x = -30;
            introBall[i].y = 240;
            introBall[i].visible = true;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 0 }, 300).to({ x: 500 }, 300).to({ x: 750 }, 300).to({ x: 1000 }, 300)
                .to({ x: 1250 }, 300).to({ x: 1350 }, 300).wait(300)
        }


        else if (i == 1 || i == 2) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i)
            introBall[i].x = 1350;
            introBall[i].y = 320;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 1350 }, 300).to({ x: 750 }, 300).to({ x: 500 }, 300).to({ x: 250 }, 300)
                .to({ x: 0 }, 300).to({ x: -200 }, 300).wait(300)
        }
        else if (i == 3) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i)
            introBall[i].x = 1350;
            introBall[i].y = 490;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 1350 }, 300).to({ x: 750 }, 300).to({ x: 500 }, 300).to({ x: 250 }, 300)
                .to({ x: 0 }, 300).to({ x: -200 }, 300).wait(300)
        }
        else if (i == 4 || i == 5 || i == 6) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i)
            introBall[i].x = -30;
            introBall[i].y = 410;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 0 }, 300).to({ x: 500 }, 300).to({ x: 750 }, 300).to({ x: 1000 }, 300)
                .to({ x: 1250 }, 300).to({ x: 1350 }, 300).wait(300);
        }
        else if (i == 7) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i);
            introBall[i].x = -30;
            introBall[i].y = 410;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 0 }, 300).to({ x: 500 }, 300).to({ x: 750 }, 300).to({ x: 1000 }, 300)
                .to({ x: 1250 }, 300).to({ x: 1350 }, 300);
        }
        else if (i == 8) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i)
            introBall[i].x = -30;
            introBall[i].y = 580;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 0 }, 300).to({ x: 500 }, 300).to({ x: 750 }, 300).to({ x: 1000 }, 300)
                .to({ x: 1250 }, 300).to({ x: 1350 }, 300);
        }
        else if (i == 9) {
            console.log("i==" + i)
            introBall[i].gotoAndStop(i);
            introBall[i].x = 1350;
            introBall[i].y = 665;
            createjs.Tween.get(introBall[i]).wait(temp2).to({ x: 1350 }, 300).to({ x: 750 }, 300).to({ x: 500 }, 300).to({ x: 250 }, 300)
            .to({ x: 0 }, 300).to({ x: -200 }, 300).wait(300).call(handleComplete3_1);
        }
        temp2 += 900
    }

}
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween()
    }
}
function choiceTween() {
    console.log("choiceTween")
    introQuestxt.visible = false;
    introImg.visible = false;


    introQuestxt1.visible = true;
    introQuestxt1.y = -1000;
    createjs.Tween.get(introQuestxt1).wait(100).to({ y: 0 }, 800, createjs.Ease.bounceOut)
        .call(handleComplete6_1);



}
function handleComplete6_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        // introCh2()
        setArrowTween();
    }
}
function introCh2() {
    createjs.Tween.get(introQuestxt1).to({ scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500).to({ scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500).wait(500).call(handleComplete7_1);
}
function handleComplete7_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    console.log("removeGameIntro")
    createjs.Tween.removeAllTweens();
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false;

    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false
    container.parent.removeChild(introQuestxt1)
    introQuestxt1.visible = false
    container.parent.removeChild(introHolder)
    introHolder.visible = false;


    for (i = 0; i < 6; i++) {
        container.parent.removeChild(introPipeArr[i]);
        introPipeArr[i].visible = true;
    }
    container.parent.removeChild(introImg);
    introImg.visible = false;


    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }




    for (i = 0; i < 10; i++) {
        container.parent.removeChild(introBall[i])
        introBall[i].visible = false;
    }

}