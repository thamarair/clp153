
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, question, circleOutline, circle1Outline, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q

var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES/////////////////////////////////////////////////////////
var currentX
var currentY, mask1, mask2, mask3, mask4, ball
var ballCnt, leftCnt, leftCnt1, rightCnt, rightCnt1, left, left1, left2, right, right1, right2, questionText1;
var rand3, valnum, colorCnt;
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var leftBalls = []
var rightBalls = []
var leftBalls1 = []
var rightBalls1 = []
var leftBalls2 = []
var rightBalls2 = []
var leftBalls3 = []
var rightBalls3 = []
var val = []
var leftColors = []
var rightColors = []
var leftColors1 = []
var rightColors1 = []
var leftColors2 = []
var rightColors2 = []
var tweenMcArr1 = []
var tweenMcArr2 = []
var tweenMcArr3 = []
var tweenMcArr4 = []
var tweenMcArr5 = []
var tweenMcArr6 = []
var ballColor = ["yellow", "brown", "red", "green", "blue", "maroon", "purple", "orange", "sandal", "dark green"]
// var c1 = [2, 8, 3, 3, 2, 8, 5, 4, 2, 4]
// var c2 = [6, 5, 5, 2, 4, 6, 3, 3, 4, 2]
// var c3 = [4, 3, 7, 4, 6, 4, 1, 6, 6, 5]
// var c4 = [3, 6, 2, 6, 5, 2, 7, 5, 4, 3]
// var c5 = [4, 3, 7, 4, 6, 4, 1, 6, 6, 5]
// var c6 = [3, 6, 2, 6, 5, 2, 7, 5, 4, 3]
var c1 = [5, 1, 1, 1, 2, 1, 1, 2, 5, 4, 4, 2];
var c2 = [3, 4, 5, 1, 3, 2, 3, 1, 3, 4, 2, 2];
var c3 = [1, 2, 4, 1, 1, 2, 2, 2, 1, 3, 5, 3];
var c4 = [2, 1, 2, 3, 1, 1, 3, 3, 4, 1, 3, 2];
var c5 = [1, 3, 1, 1, 4, 1, 2, 2, 2, 3, 1, 2];
var c6 = [1, 3, 2, 2, 3, 3, 2, 2, 2, 2, 3, 1];

// var ansVal=[2,1,3,4,3,4,3,2,1,2]
var ansVal = [0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5]
var caseNo = [1, 2, 3, 4, 3, 4, 3, 2, 1, 2]
var choose = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2]
var introImg, introImg1
var choiceArr1 = [];
var choiceArr2 = [];
var PosX1 = [0, 0, 0, 1155, 1155, 1155];
var PosY1 = [182, 370, 558, 272, 460, 650];


//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);


    createLoader()

    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "RunningBalls-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(

            { id: "chHolder", src: gameAssetsPath + "Holder.png" },
            { id: "iHolder", src: gameAssetsPath + "Holder1.png" },
            { id: "balls", src: gameAssetsPath + "balls.png" },
            { id: "ballsPipe", src: gameAssetsPath + "ballsPipe.png" },
            { id: "questionText", src: questionTextPath + "RunningBalls-Level2-QT.png" },
            { id: "questionText1", src: questionTextPath + "RunningBalls-Level2-QT1.png" },
            { id: "questionText2", src: questionTextPath + "RunningBalls-Level2-QT2.png" },
            { id: "introImg", src: questionTextPath + "Hint/RunningBalls-Level2-Hint.png" }

        )
        preloadAllAssets()
        stage.update();
    }
}
//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    console.log("get Id =" + id)
    if (id == "introImg") {

        introImg = new createjs.Bitmap(preload.getResult('introImg'));
        container.parent.addChild(introImg);
        introImg.visible = false;
    }
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "questionText1") {

        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }
    if (id == "questionText2") {

        questionText2 = new createjs.Bitmap(preload.getResult('questionText2'));
        container.parent.addChild(questionText2);
        questionText2.visible = false;
    }
    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }
	if (id == "iHolder") {
        iHolder = new createjs.Bitmap(preload.getResult('iHolder'));
        container.parent.addChild(iHolder);
        iHolder.visible = false;
    }

    if (id == "balls") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("balls")],
            "frames": { "regX": 50, "height": 80, "count": 0, "regY": 50, "width": 80 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        ball = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(ball);
        ball.visible = false;
        //			 
    }
    if (id == "ballsPipe") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("ballsPipe")],
            "frames": { "regX": 50, "height": 90, "count": 0, "regY": 50, "width": 230 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        ballsPipe = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(ballsPipe);
        ballsPipe.visible = false;
        //			 
    }

}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 11);
    // qno = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    caseNo.sort(randomSort)
    console.log(caseNo)
    choose.sort(randomSort)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() {
    interval = setInterval(countTime, 1000);
    container.parent.addChild(chHolder);
    chHolder.visible = true;
    container.parent.addChild(questionText);
    questionText.visible = false;

    container.parent.addChild(questionText1);
    questionText1.visible = false;

    container.parent.addChild(questionText2);
    questionText2.visible = false;

    for (i = 0; i < 6; i++) {
        choiceArr1[i] = ballsPipe.clone();
        container.parent.addChild(choiceArr1[i])
        choiceArr1[i].x = PosX1[i];
        choiceArr1[i].y = PosY1[i];
        choiceArr1[i].name = i + 1;
        choiceArr1[i].visible = true;
        choiceArr1[i].gotoAndStop(i);
    }


}
//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//==================================================================PICKQUES==========================================================================//
function pickques() {

    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    panelVisibleFn()
    rightColors = []
    leftColors = []
    rightColors1 = []
    leftColors1 = []
    rightColors2 = []
    leftColors2 = []
    val = [];
    // qno[cnt] = 0
    //=================================================================
    console.log("qno===" + qno[cnt])

    questionText.visible = true;
    leftCnt = c1[qno[cnt]]
    leftCnt1 = c2[qno[cnt]]
    leftCnt2 = c3[qno[cnt]]
    rightCnt = c4[qno[cnt]]
    rightCnt1 = c5[qno[cnt]]
    rightCnt2 = c6[qno[cnt]]


    left = -1;
    right = -1;
    left1 = -1;
    right1 = -1;
    left2 = -1;
    right2 = -1;
    console.log(c1[qno[cnt]] + " ==leftCnt  " + c2[qno[cnt]] + " ==leftCnt 1  " + c3[qno[cnt]] + " ==rightCnt " + c4[qno[cnt]] + " ==rightCnt 1 ")

    callBallFn();

}
function callBallFn() {
    var cno = range(0, 6)
    console.log("cno==" + cno)

    if (cno == 0) {

        if (left < leftCnt) {
            console.log("left==" + left)
            createLeftBalls();
        }
        else if (left == leftCnt) {
            console.log("both same left")
            callBallFn();
        }
    }
    else if (cno == 1) {

        if (left1 < leftCnt1) {
            createLeftBalls1();
        }
        else if (left1 == leftCnt1) {
            console.log("both same left1")
            callBallFn();
        }

    }
    else if (cno == 2) {
        if (left2 < leftCnt2) {
            createLeftBalls2();
        }
        else if (left2 == leftCnt2) {
            console.log("both same left2")
            callBallFn();
        }
    }
    else if (cno == 3) {
        if (right < rightCnt) {
            createRightBalls();
        }
        else if (right == rightCnt) {
            console.log("both same right1")
            callBallFn();

        }
    }
    else if (cno == 4) {
        if (right1 < rightCnt1) {
            createRightBalls1();
        }
        else if (right1 == rightCnt1) {
            console.log("both same right1")
            callBallFn();

        }
    }
    else if (cno == 5) {
        if (right2 < rightCnt2) {
            createRightBalls2();
        }
        else if (right2 == rightCnt2) {
            console.log("both same right2")
            callBallFn();

        }
    }
    for (i = 0; i < 6; i++) {
        choiceArr1[i] = ballsPipe.clone();
        container.parent.addChild(choiceArr1[i])
        choiceArr1[i].x = PosX1[i];
        choiceArr1[i].y = PosY1[i];
        choiceArr1[i].name = i + 1;
        choiceArr1[i].visible = true;
        choiceArr1[i].gotoAndStop(i);
    }
}
function createLeftBalls() {
    left++;
    if (left < leftCnt) {
        var rand1 = range(0, 9)
        leftColors.push(rand1)
        leftBalls[left] = ball.clone();
        container.parent.addChild(leftBalls[left])
        leftBalls[left].visible = true;
        leftBalls[left].gotoAndStop(rand1)
        leftBalls[left].x = -10;
        leftBalls[left].y = 185
        leftBalls[left].scaleX = leftBalls[left].scaleY = 1;
        console.log(rand1 + "    ")
        tweenMcArr1[left] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr1[left])
        container.parent.addChild(mask1);
        tweenMcArr1[left].timeline.addTween(createjs.Tween.get(leftBalls[left]).to({ x: 0 }, 5).to({ x: 500 }, 5).to({ x: 750 }, 5).to({ x: 1000 }, 7)
            .to({ x: 1250 }, 7).to({ x: 1350 }, 7).wait(12));
        setTimeout(stopTween1, 1400);
    } else {
        showQues();
    }
}
function stopTween1() {
    tweenMcArr1[left].stop();
    leftBalls[left].visible = false;
    callBallFn();
    //  createLeftBalls()
}
function createLeftBalls1() {
    left1++;
    if (left1 < leftCnt1) {
        var rand1 = range(0, 9)
        leftColors1.push(rand1)
        leftBalls1[left1] = ball.clone();
        container.parent.addChild(leftBalls1[left1])
        leftBalls1[left1].visible = true;
        leftBalls1[left1].gotoAndStop(rand1)
        leftBalls1[left1].x = -10;
        leftBalls1[left1].y = 370
        leftBalls1[left1].scaleX = leftBalls1[left1].scaleY = 1;
        console.log(rand1 + "    ")
        tweenMcArr2[left1] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr2[left1])
        container.parent.addChild(mask1);
        tweenMcArr2[left1].timeline.addTween(createjs.Tween.get(leftBalls1[left1]).to({ x: 0 }, 7).to({ x: 500 }, 7).to({ x: 750 }, 7).to({ x: 1000 }, 7)
            .to({ x: 1250 }, 7).to({ x: 1350 }, 7).wait(12));
        setTimeout(stopTween2, 1400);
    } else {

        showQues();
    }
}
function stopTween2() {
    tweenMcArr2[left1].stop();
    leftBalls1[left1].visible = false;
    callBallFn();
    // createLeftBalls1()
}

function createLeftBalls2() {
    left2++;
    if (left2 < leftCnt2) {
        var rand1 = range(0, 9)
        leftColors2.push(rand1)
        leftBalls2[left2] = ball.clone();
        container.parent.addChild(leftBalls2[left2])
        leftBalls2[left2].visible = true;
        leftBalls2[left2].gotoAndStop(rand1)
        leftBalls2[left2].x = -10;
        leftBalls2[left2].y = 560
        leftBalls2[left2].scaleX = leftBalls2[left2].scaleY = 1
        console.log(rand1 + "    ")
        tweenMcArr3[left2] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr3[left2])
        container.parent.addChild(mask1);
        tweenMcArr3[left2].timeline.addTween(createjs.Tween.get(leftBalls2[left2]).to({ x: 0 }, 7).to({ x: 500 }, 7).to({ x: 750 }, 7).to({ x: 1000 }, 7)
            .to({ x: 1250 }, 7).to({ x: 1350 }, 7).wait(12));
        setTimeout(stopTween3, 1400);
    } else {

        showQues();
    }
}
function stopTween3() {
    tweenMcArr3[left2].stop();
    leftBalls2[left2].visible = false;
    callBallFn();
    // createLeftBalls1()
}

function createRightBalls() {
    right++
    if (right < rightCnt) {
        var rand2 = range(0, 9)
        rightColors.push(rand2)
        rightBalls[right] = ball.clone();
        container.parent.addChild(rightBalls[right])
        rightBalls[right].visible = true
        rightBalls[right].gotoAndStop(rand2)
        rightBalls[right].x = 1300
        rightBalls[right].y = 270
        console.log(rand2 + "    ")

        rightBalls[right].scaleX = rightBalls[right].scaleY = 1
        tweenMcArr4[right] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr4[right])
        container.parent.addChild(mask4);
        tweenMcArr4[right].timeline.addTween(createjs.Tween.get(rightBalls[right])
            .to({ x: 1250 }, 7).to({ x: 750 }, 7).to({ x: 500 }, 7).to({ x: 250 }, 7)
            .to({ x: 0 }, 7).to({ x: -200 }, 7).wait(12));
        setTimeout(stopTween4, 1400);
    } else {
        showQues();
    }
}

function stopTween4() {
    tweenMcArr4[right].stop();
    rightBalls[right].visible = false
    callBallFn();
    // createRightBalls()

}
function createRightBalls1() {
    right1++
    if (right1 < rightCnt1) {
        var rand2 = range(0, 9)
        rightColors1.push(rand2)
        rightBalls1[right1] = ball.clone();
        container.parent.addChild(rightBalls1[right1])
        rightBalls1[right1].visible = true
        rightBalls1[right1].gotoAndStop(rand2)
        rightBalls1[right1].x = 1300
        rightBalls1[right1].y = 470
        console.log(rand2 + "    ")

        rightBalls1[right1].scaleX = rightBalls1[right1].scaleY = 1
        tweenMcArr5[right1] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr5[right1])
        container.parent.addChild(mask4);
        tweenMcArr5[right1].timeline.addTween(createjs.Tween.get(rightBalls1[right1])
            .to({ x: 1250 }, 7).to({ x: 750 }, 7).to({ x: 500 }, 7).to({ x: 250 }, 7)
            .to({ x: 0 }, 7).to({ x: -200 }, 7).wait(12));
        setTimeout(stopTween5, 1400);
    } else {
        showQues();
    }
}
function stopTween5() {
    tweenMcArr5[right1].stop();
    rightBalls1[right1].visible = false;
    callBallFn();
    // createRightBalls1()

}
function createRightBalls2() {
    right2++
    if (right2 < rightCnt2) {
        var rand2 = range(0, 9)
        rightColors2.push(rand2)
        rightBalls2[right2] = ball.clone();
        container.parent.addChild(rightBalls2[right2])
        rightBalls2[right2].visible = true
        rightBalls2[right2].gotoAndStop(rand2)
        rightBalls2[right2].x = 1300
        rightBalls2[right2].y = 650
        console.log(rand2 + "    ")

        rightBalls2[right2].scaleX = rightBalls2[right2].scaleY = 1
        tweenMcArr6[right2] = new createjs.MovieClip()
        container.parent.addChild(tweenMcArr6[right2])
        container.parent.addChild(mask4);
        tweenMcArr6[right2].timeline.addTween(createjs.Tween.get(rightBalls2[right2])
            .to({ x: 1250 }, 7).to({ x: 750 }, 7).to({ x: 500 }, 7).to({ x: 250 }, 7)
            .to({ x: 0 }, 7).to({ x: -200 }, 7).wait(12));
        setTimeout(stopTween6, 1400);
    } else {
        showQues();
    }
}

function stopTween6() {
    tweenMcArr6[right2].stop();
    rightBalls2[right2].visible = false;
    callBallFn();
    // createRightBalls1()

}
function showQues() {

    if (left == leftCnt && right == rightCnt && left1 == leftCnt1 && right1 == rightCnt1 && left2 == leftCnt2 && right2 == rightCnt2) {
        if (qno[cnt] < 6) {
            // questionText.gotoAndStop(0)

        }
        else if (qno[cnt] >= 6 || qno[cnt] < 12) {
            // questionText.gotoAndStop(1)
        }

        ans = ansVal[qno[cnt]]
        console.log("condition achieved" + ans)
        enablechoices();

    }
    else if (left == leftCnt) {
        callBallFn();

    }
    else if (left1 == leftCnt1) {
        callBallFn();

    }
    else if (left2 == leftCnt2) {
        callBallFn();

    }
    else if (right1 == rightCnt1) {
        callBallFn();

    }
    else if (right2 == rightCnt2) {
        callBallFn();

    }
    else {
        callBallFn();
        console.log("condition never achieved")
    }



}
//====================================================================CHOICE ENABLE/DISABLE==============================================================//
function enablechoices() {
    // questionText1.visible = false
    questionText.visible = false


    for (i = 0; i < 6; i++) {
        choiceArr1[i].visible = false;
    }

    createTween()
}
function createTween() {
    questionText.visible = false;
    if (qno[cnt] < 6) {
        questionText1.visible = true;
        questionText1.alpha = 0
        questionText1.y = -1000;
        createjs.Tween.get(questionText1).wait(100).to({ alpha: 1,y:0 }, 800, createjs.Ease.bounceOut);

    }
    else if (qno[cnt] >= 6 || qno[cnt] < 12) {
        questionText2.visible = true;
        questionText2.alpha = 0
        questionText2.y = -1000;
        createjs.Tween.get(questionText2).wait(100).to({ alpha: 1, y: 0 }, 800, createjs.Ease.bounceOut);
    }


    repTimeClearInterval = setTimeout(AddListenerFn, 1000)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")

    for (i = 0; i < 6; i++) {
        // choiceArr2[i].mouseEnabled = true;
        // choiceArr2[i].visible = true;
        // choiceArr2[i].cursor = "pointer";
        // choiceArr2[i].name = i + 2;
        // choiceArr2[i].addEventListener("click", answerSelected)

        choiceArr1[i].mouseEnabled = true;
        choiceArr1[i].visible = true;
        choiceArr1[i].cursor = "pointer";
        choiceArr1[i].name = i;
        choiceArr1[i].addEventListener("click", answerSelected)
    }



    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    questionText.visible = false;
    questionText1.visible = false;
    questionText2.visible = false;
    ball.visible = false;
    for (i = 0; i < 6; i++) {
        choiceArr1[i].mouseEnabled = false;
        choiceArr1[i].cursor = "default";
        choiceArr1[i].visible = false;
        choiceArr1[i].removeEventListener("click", answerSelected)
    }
}

//=================================================================ANSWER SELECTION=======================================================================//
function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    if (ans == uans) {
        // currentX = e.currentTarget.x - 30
        // currentY = e.currentTarget.y - 40
        e.currentTarget.visible = true;
        disableMouse()
        setTimeout(correct, 500)

    } else {
        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {
    for (i = 0; i < 6; i++) {
        // choiceArr2[i].mouseEnabled = false
        choiceArr1[i].mouseEnabled = false
    }

}


