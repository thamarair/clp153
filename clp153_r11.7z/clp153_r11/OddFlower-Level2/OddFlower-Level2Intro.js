var introQues1, introTitle, introQuestxt, introChoice1, introChoice2, introChoice3, introHolder, introArrow, introfingure, introquestionText1;
var introChoice1TweenArr = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introQues1X = 465, introQues1Y = 170;
var introChoice1X = 90, introChoice1Y = 1000;
var introChoice2X = 870, introChoice2Y = 1000;
var introArrowX = 230, introArrowY = 450;
var introfingureX = 280, introfingureY = 580;
var introichArr = [];
var introiCText = [];
var introArrowX = 615, introArrowY = 340;
var introfingureX = 680, introfingureY = 500;
var iquesArr = [];
var iqText = [];
var ichArr = [];
var iCText = [];
function commongameintro() {

    introTitle = Title.clone();
    introQuestxt = questionText.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();

    container.parent.addChild(introTitle);
    introTitle.visible = true;

    container.parent.addChild(introQuestxt);
    introQuestxt.visible = false;



    for (i = 0; i < 3; i++) {
        iquesArr[i] = question.clone();
        iquesArr[i].visible = false;
        iquesArr[i].x = btnX[i];
        iquesArr[i].y = btnY[i];
        iquesArr[i].gotoAndStop(i+1);
        container.parent.addChild(iquesArr[i]);

    }
    var ival = [28,87,97,98,38,27,36,98,37,46,58,47,56,68,57,66,78,98];
    for (i = 0; i < 18; i++) {
        iqText[i] = new createjs.Text(ival[i], "40px lato-Bold", "black");
        container.parent.addChild(iqText[i]);
        iqText[i].textBaseline = "middle";
        iqText[i].textAlign = "center";
        iqText[i].lineWidth = 10;
        iqText[i].lineHeight = 10;
        iqText[i].x = btnX1[i];
        iqText[i].y = btnY1[i];
        iqText[i].visible = false;
    }

    var ival1 = [35,98,26]
    for (i = 0; i < choiceCnt; i++) {
        ichArr[i] = choice1.clone();
        ichArr[i].visible = false;
        ichArr[i].x = btnX2[i];
        ichArr[i].y = btnY2[i];
        container.parent.addChild(ichArr[i]);

        iCText[i] = new createjs.Text(ival1[i], "100px lato-Bold", "black");
        container.parent.addChild(iCText[i]);
        iCText[i].x = 260; iCText[i].y = 620;
        iCText[i].textAlign = "center";
        iCText[i].lineWidth = 10;
        iCText[i].lineHeight = 10;
        iCText[i].textBaseline = "middle";
        iCText[i].x = btnX2[i] + 135;
        iCText[i].y = btnY2[i] + 140;
        iCText[i].visible = false;

    }


    container.parent.addChild(introImg);
    introImg.visible = false;
    introImg.x=110;introImg.y=180;

    introQuestxt.visible = true;
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 500).call(handleComplete1_1);


}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        quesTween();
    }
}

function quesTween() {
    for (i = 0; i < 3; i++) {
        iquesArr[i].visible = true;
        iquesArr[i].alpha = 0;
        createjs.Tween.get(iquesArr[i]).wait(100)
            .to({ alpha: 1 });
    }
    for (i = 0; i < 18; i++) {
        if (i == 17) {
            createjs.Tween.get(iqText[i]).wait(200)
                .to({ alpha: 1, visible: true }).wait(2000).call(handleComplete2_1);
        } else {
            createjs.Tween.get(iqText[i]).wait(200)
                .to({ alpha: 1, visible: true });
        }
    }
}
function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween();
    }
}
function choiceTween() {

    for (i = 0; i < 18; i++) {
        iqText[i].visible = false;
    }
    for (i = 0; i < choiceCnt; i++) {
        ichArr[i].visible = true;
        ichArr[i].alpha = 0;
        createjs.Tween.get(ichArr[i]).wait(100).to({ alpha: 1 });
    }
    for (i = 0; i < choiceCnt; i++) {
        iCText[i].visible = true;
        iCText[i].alpha = 0;
        if (i == 2) {
            createjs.Tween.get(iCText[i]).wait(200).to({ alpha: 1 }).wait(500).call(handleComplete3_1);
        } else {
            createjs.Tween.get(iCText[i]).wait(200).to({ alpha: 1 });
        }
    }




    TempIntroVal = 0;
}

function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        introCh();
    }
}
function introCh() {
    introImg.visible = true;
    createjs.Tween.get(introImg).to({ alpha: 0.5 }, 300).to({ alpha: 1 }, 300).wait(2000).call(handleComplete4_1);
}

function handleComplete4_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        
    introImg.visible = false;
        if (TempIntroVal == 1) {
            introichArr[0].visible = false;
            introiCText[0].visible = false;

        }
        setArrowTween();
    }
}


function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {
        // introAns.visible = true;
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {

        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();

    // container.parent.removeChild(introImg);
    // introImg.visible = false;
    container.parent.removeChild(introArrow)
    introArrow.visible = false;
    container.parent.removeChild(introfingure)
    introfingure.visible = false;
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false;

    


    for (i = 0; i < 3; i++) {
        iquesArr[i].visible = false;
        container.parent.removeChild(iquesArr[i]);

    }

    for (i = 0; i < 18; i++) {
        container.parent.removeChild(iqText[i]);
        iqText[i].visible = false;
    }

    for (i = 0; i < choiceCnt; i++) {
        ichArr[i].visible = false;
        container.parent.removeChild(ichArr[i]);

        container.parent.removeChild(iCText[i]);
        iCText[i].visible = false;

    }


    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}
