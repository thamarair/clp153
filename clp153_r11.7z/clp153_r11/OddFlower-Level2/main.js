
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;

var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var px = [100, 320, 540, 760, 980]
var py = [295, 295, 295, 480, 480]
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var currentX, currentY
var introImg
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var choiceArr = []
var qType = []
var quesMcArr1 = [];
var AnswerImage = [];
//register key functions
var qno1 = [];
var choiceText = [];
var quesText = [];
var btnX = [120, 490, 870];
var btnY = [220, 400, 220];
var btnX1 = [155, 155, 265, 265, 372, 372, 525, 525, 633, 633, 740, 740, 903, 903, 1012, 1012, 1120, 1120];
var btnY1 = [305, 410, 250, 470, 305, 410, 490, 590, 430, 650, 490, 590, 305, 410, 250, 470, 305, 410];
var btnX2 = [125, 500, 875];
var btnY2 = [220, 400, 220];
var quesArr = [];
var rand
var randArr = [];
var rand1, rand2, rand3;
var qArr = []
var ansVal;
var randVal = [];
var indexArr = [];
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader()
    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questionText.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "OddFlower-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "questionText", src: questionTextPath + "OddFlower-Level2-QT.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            // { id: "qHolder2", src: gameAssetsPath + "Holder2.png" },
            { id: "introImg", src: gameAssetsPath + "introImg.png" }

        )
        preloadAllAssets()
        stage.update();
    }
}

//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;


    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 370, "count": 0, "regY": 50, "width": 385 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);

    };

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

    if (id == "choice1") {
        choice1 = new createjs.Bitmap(preload.getResult('choice1'));
        container.parent.addChild(choice1);
        choice1.visible = false;
    }

    // if (id == "qHolder2") {
    //     qHolder2 = new createjs.Bitmap(preload.getResult('qHolder2'));
    //     container.parent.addChild(qHolder2);
    //     qHolder2.visible = false;
    // }

    if (id == "introImg") {
        introImg = new createjs.Bitmap(preload.getResult('introImg'));
        container.parent.addChild(introImg);
        introImg.visible = false;
    }

}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 15);
    // qno.splice(qno.indexOf(0), 1);
    // qno.push(0);
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}
function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questionText);
    questionText.visible = false;

    for (i = 0; i < 3; i++) {
        quesArr[i] = question.clone();
        quesArr[i].visible = false;
        quesArr[i].x = btnX[i];
        quesArr[i].y = btnY[i];
        container.parent.addChild(quesArr[i]);

    }
    for (i = 0; i < 18; i++) {
        quesText[i] = new createjs.Text("00", "40px lato-Bold", "black");
        container.parent.addChild(quesText[i]);
        quesText[i].textBaseline = "middle";
        quesText[i].textAlign = "center";
        quesText[i].lineWidth = 10;
        quesText[i].lineHeight = 10;
        quesText[i].x = btnX1[i];
        quesText[i].y = btnY1[i];
        quesText[i].visible = false;
    }

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = choice1.clone();
        choiceArr[i].visible = false;
        choiceArr[i].x = btnX2[i];
        choiceArr[i].y = btnY2[i];
        container.parent.addChild(choiceArr[i]);

        choiceText[i] = new createjs.Text("88", "100px lato-Bold", "black");
        container.parent.addChild(choiceText[i]);
        choiceText[i].x = 260; choiceText[i].y = 620;
        choiceText[i].textAlign = "center";
        choiceText[i].lineWidth = 10;
        choiceText[i].lineHeight = 10;
        choiceText[i].textBaseline = "middle";
        choiceText[i].x = btnX2[i] + 135;
        choiceText[i].y = btnY2[i] + 140;
        choiceText[i].visible = false;

    }
    if (isQuestionAllVariations) {
        qType = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        // createGameWiseQuestions()
        //pickques()
    } else {
        qType = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        // pickques()
    }
    qType.sort(randomSort)
}
function helpDisable() {
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    pauseTimer()
    tx = 0;
    qscnt++;
    cnt++;
    quesCnt++;
    chpos = [];
    panelVisibleFn();
    randVal = 0;
    rand = 0;
    rand1 = 0;
    rand2 = 0;
    rand3 = 0;
    randArr = [];
    qArr =  [];

    //=================================================================================================================================//
    rand = range(10, 99);
    console.log(rand);
    randArr = between(10, 99);
    randArr.splice(randArr.indexOf(rand), 1);
    // console.log(randArr);
    rand1 = range(0, 5);
    rand2 = range(6, 11);
    rand3 = range(12, 18);
    randVal = range(0, 3);
    qArr = between(0, 15);

    for (i = 0; i < 3; i++) {
        quesArr[i].gotoAndStop(qArr[i]);
    }
    for (i = 0; i < 18; i++) {
        quesText[i].text = randArr[10 + i];
        quesText[i].visible = false;
    }

    quesText[rand1].text = rand;
    quesText[rand2].text = rand;
    quesText[rand3].text = rand;


    for (i = 0; i < choiceCnt; i++) {
        choiceText[i].text = randArr[15 + i];
        choiceArr[i].name = i;

    }
    choiceText[randVal].text = rand;
    choiceArr[randVal].name = randVal;

    ans = randVal;

    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
function createTween() {
    //////////////////////////////questionText////////////////////////////
    questionText.visible = true;
    questionText.alpha = 0;
    createjs.Tween.get(questionText).wait(100)
        .to({ alpha: 1 });

    for (i = 0; i < 3; i++) {
        quesArr[i].visible = true;
        quesArr[i].alpha = 0;
        createjs.Tween.get(quesArr[i]).wait(150)
            .to({ alpha: 1 });
    }
    for (i = 0; i < 18; i++) {
        createjs.Tween.get(quesText[i]).wait(200)
            .to({ alpha: 1, visible: true });
    }


    repTimeClearInterval1 = setTimeout(createTween1, 3500)
}

function createTween1() {
    clearTimeout(repTimeClearInterval1)
    for (i = 0; i < 18; i++) {
        quesText[i].visible = false;
    }
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = true;
        choiceArr[i].alpha = 0;
        createjs.Tween.get(choiceArr[i]).wait(100).to({ alpha: 1 });
    }
    for (i = 0; i < choiceCnt; i++) {
        choiceText[i].visible = true;
        choiceText[i].alpha = 0;
        createjs.Tween.get(choiceText[i]).wait(200).to({ alpha: 1 });
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 1000)
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].visible = true;
        choiceArr[i].cursor = "pointer";
        choiceText[i].visible = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}

function disablechoices() {
    questionText.visible = false;
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].visible = false;
        choiceArr[i].alpha = 0;
        choiceText[i].visible = false;
    }
    for (i = 0; i < 3; i++) {
        quesArr[i].visible = false;

    }
    for (i = 0; i < 18; i++) {
        quesText[i].visible = false;
    }
}

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    if (ans == uans) {
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].removeEventListener("click", answerSelected);
        }
        getValidation("correct");
        disablechoices();
    } else {

        getValidation("wrong");
        disablechoices();
    }
}
//===============================//