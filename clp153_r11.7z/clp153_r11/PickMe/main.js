
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;

var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var currentX, currentY
var introImg;

///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var choiceArr = []
var posArr = []
var quesMcArr1 = [];
var AnswerImage = [];
var btnX = [, 145, 910, 525];
var btnY = [, 310, 310, 310];
//register key functions
var introImg;
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader()
    createCanvasResize()


    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questionText.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "PickMe/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "questionText", src: questionTextPath + "PickMe-QT.png" },
            { id: "questionText1", src: questionTextPath + "PickMe-QT1.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "ChoiceImages2.png" },
            { id: "choice3", src: gameAssetsPath + "ChoiceImages3.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "introImg", src: gameAssetsPath + "introImg.png" }
            // { id: "answer", src: gameAssetsPath + "Answer.png" }

        )
        preloadAllAssets()
        stage.update();
    }
}

//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;

    if (id == "questionText") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("questionText")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 812 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        questionText = new createjs.Sprite(spriteSheet2);
        questionText.visible = false;
        container.parent.addChild(questionText);
    };
    

    if (id == "questionText1") {
        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }

    if (id == "introImg") {
        introImg = new createjs.Bitmap(preload.getResult('introImg'));
        container.parent.addChild(introImg);
        introImg.visible = false;
    }



    if (id == "choice1") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 308, "count": 0, "regY": 50, "width": 383 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        choice1 = new createjs.Sprite(spriteSheet2);
        choice1.visible = false;
        container.parent.addChild(choice1);
        choice1.x = 130; choice1.y = 450;
    };

    if (id == "choice2") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 308, "count": 0, "regY": 50, "width": 383 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        choice2 = new createjs.Sprite(spriteSheet2);
        choice2.visible = false;
        container.parent.addChild(choice2);
    };

    if (id == "choice3") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice3")],
            "frames": { "regX": 50, "height": 308, "count": 0, "regY": 50, "width": 383 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        choice3 = new createjs.Sprite(spriteSheet2);
        choice3.visible = false;
        container.parent.addChild(choice3);
    };

    if (id == "question") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 580, "count": 0, "regY": 50, "width": 720 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        question = new createjs.Sprite(spriteSheet2);
        question.visible = false;
        container.parent.addChild(question);
    };

}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 29);
    qno.splice(qno.indexOf(0), 1);
    qno.push(0)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}
function CreateGameElements() {
    interval = setInterval(countTime, 1000);


    container.parent.addChild(questionText);
    questionText.visible = false;
    questionText.x = 300; questionText.y = 110;

    container.parent.addChild(questionText1);
    questionText1.visible = false;

    container.parent.addChild(question);
    question.visible = false;
    question.scaleX = question.scaleY = .8;
    question.x = 400; question.y = 220;

    container.parent.addChild(choice1, choice2, choice3);
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i] = this["choice" + i].clone();
        choiceArr[i].visible = false;
        choiceArr[i].x = btnX[i];
        choiceArr[i].y = btnY[i];
        choiceArr[i].scaleX = choiceArr[i].scaleY = .8;
        container.parent.addChild(choiceArr[i]);
    }

    if (isQuestionAllVariations) {
        posArr = [0, 1, 2, 0, 1, 2, 0, 1, 2, 1, 0, 1, 2, 0, 1, 2, 0, 1, 2, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0]
        // createGameWiseQuestions()
        //pickques()
    } else {
        posArr = [0, 1, 2, 0, 1, 2, 0, 1, 2, 1]
        // pickques()
    }
    posArr.sort(randomSort)
}
function helpDisable() {
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    pauseTimer()
    tx = 0;
    qscnt++;
    cnt++;
    quesCnt++;
    chpos = [];
    panelVisibleFn()
    //=================================================================================================================================//

    question.gotoAndStop(qno[cnt]);
    questionText.gotoAndStop(qno[cnt]);
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].gotoAndStop(qno[cnt]);
        choiceArr[i].name = "ch" + i;

    }
    ans = "ch1";

    if (posArr[cnt] == 0) {
        chpos.push(1, 3, 2)
    } else if (posArr[cnt] == 1) {
        chpos.push(2, 3, 1)
    } else {
        chpos.push(3, 1, 2)
    }

    console.log("..chpos...." + chpos)
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].x = btnX[chpos[i - 1]];
        choiceArr[i].y = btnY[chpos[i - 1]];
    }
    console.log("......" + choiceArr)
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
function createTween() {


    questionText.visible = true
    questionText.alpha = 0;
    createjs.Tween.get(questionText).wait(100)
        .to({ alpha: 1 }, 100);


    question.visible = true;
    question.alpha = 0;
    createjs.Tween.get(question).wait(150)
        .to({ alpha: 1 }, 100);
    repTimeClearInterval = setTimeout(createTween1, 2500)
}
function createTween1() {
    questionText.visible = false;
    question.visible = false;

    questionText1.visible = true;
    questionText1.alpha = 0;
    createjs.Tween.get(questionText1).wait(100)
        .to({ alpha: 1 }, 100);

    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].visible = true;
        choiceArr[i].alpha = 0;
        createjs.Tween.get(choiceArr[i]).wait(300).to({ alpha: 0.5 }, 500).to({ alpha: 1 }, 500);
    }

    repTimeClearInterval = setTimeout(AddListenerFn, 1500);
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].visible = true;
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true
        choiceArr[i].cursor = "pointer";
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}

function disablechoices() {
    questionText1.visible = false;
    questionText.visible = false;
    question.visible = false
    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].visible = false;
    }

}


function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    if (ans == uans) {
        // e.currentTarget.visible = true;
        disableMouse()
        // answer.visible = true;
        for (i = 1; i <= choiceCnt; i++) {
            choiceArr[i].removeEventListener("click", answerSelected);
        }
        //  createjs.Tween.get(AnswerImage)
        //     .to({ visible:true,alpha:1 })
        setTimeout(correct, 200);
    } else {

        getValidation("wrong");
        disablechoices();
    }
}
function correct() {
    getValidation("correct");
    disablechoices();
}
function disableMouse() {

    for (i = 1; i <= choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false
        choiceArr[i].visible = false;
    }
}
function enableMouse() {

}
//===========================================================================================//


