var introQues1, introTitle, introQuestxt, introChoice1, introAns, introChoice2, introChoice3, introQuestxt1, introHolder, introArrow, introfingure, introQues2;
var introChoice1TweenArr = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introQues1X = 515, introQues1Y = 190
var introChoice1X = 620, introChoice1Y = 335;
var introChoice2X = 850, introChoice2Y = 335;
var introChoice3X = 1080, introChoice3Y = 335;
var introArrowX = 665, introArrowY = 210;
var introfingureX = 680, introfingureY = 410;

function commongameintro() {

    introTitle = Title.clone();
    introQuestxt = questionText.clone();
    introQuestxt1 = questionText1.clone();
    introQues1 = question.clone();
    introChoice1 = choice1.clone();
    introChoice2 = choice2.clone();
    introChoice3 = choice3.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();

    container.parent.addChild(introTitle);
    introTitle.visible = true;

    container.parent.addChild(introQuestxt)
    introQuestxt.visible = true;
    introQuestxt.x = 300; introQuestxt.y = 110;

    container.parent.addChild(introQuestxt1)
    introQuestxt1.visible = false;

    container.parent.addChild(introQues1);
    introQues1.visible = false;
    introQues1.scaleX = introQues1.scaleY = .8;
    introQues1.x = 400; introQues1.y = 220;

    container.parent.addChild(introChoice1)
    introChoice1.scaleX = introChoice1.scaleY = .5;
    introChoice1.x = introChoice1X;
    introChoice1.y = introChoice1Y;
    introChoice1.visible = false;
    introChoice1.gotoAndStop(0);
    container.parent.addChild(introChoice2)
    introChoice2.scaleX = introChoice2.scaleY = .5;
    introChoice2.visible = false;
    introChoice2.x = introChoice2X;
    introChoice2.y = introChoice2Y;
    introChoice2.gotoAndStop(0)
    container.parent.addChild(introChoice3)
    introChoice3.scaleX = introChoice3.scaleY = .5;
    introChoice3.visible = false;
    introChoice3.x = introChoice3X;
    introChoice3.y = introChoice3Y;
    introChoice3.gotoAndStop(0)

    container.parent.addChild(introImg);
    introImg.x = 60;
    introImg.y = 235;
    introImg.scaleX = introImg.scaleY = .8;
    introImg.regX=introImg.regY=50;
    introImg.visible = false;

    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ alpha: 1 }, 500).call(handleComplete1_1);


}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        quesTween()
    }
}

function quesTween() {

    introQues1.visible = true;
    introQues1.alpha = 0;
    createjs.Tween.get(introQues1).wait(150)
        .to({ alpha: 1 }, 100).wait(2000).call(handleComplete2_1);


}
function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro();
    }
    else {

        choiceTween();
    }
}
function choiceTween() {
    introQuestxt.visible = false;
    introQues1.visible = false;

    introQuestxt1.visible = true;
    introQuestxt1.alpha = 0;
    createjs.Tween.get(introQuestxt1).wait(100)
        .to({ alpha: 1 }, 100);

    for (i = 1; i <= 3; i++) {
        this["introChoice" + i].visible = true;
        this["introChoice" + i].alpha = 0;
        if (i == 3) {
            createjs.Tween.get(this["introChoice" + i]).wait(300).to({ alpha: 0.5 }, 500).to({ alpha: 1 }, 500).wait(500).call(handleComplete3_1);
        } else {
            createjs.Tween.get(this["introChoice" + i]).wait(300).to({ alpha: 0.5 }, 500).to({ alpha: 1 }, 500);
        }
    }

}

function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro();
    }
    else {

        introCh();
    }
}
function introCh() {
    introQuestxt.visible = true;
    introQuestxt.x = 95; introQuestxt.y = 170;
    introImg.visible = true;
    createjs.Tween.get(introImg).to({ alpha: 0.5 }, 1000).to({ alpha: 1 }, 500)
        .wait(500).call(handleComplete4_1);
}
function handleComplete4_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro();
    }
    else {
        introCh1();
    }
}
function introCh1() {
    createjs.Tween.get(introChoice1).to({ scaleX:.55, scaleY:.55 }, 1000).to({ scaleX: .5, scaleY: .5 }, 500)
        .to({ scaleX:.55, scaleY:.55 }, 1000).to({ scaleX: .5, scaleY: .5 }, 500).wait(2000).call(handleComplete5_1);
}
function handleComplete5_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro();
    }
    else {
        setArrowTween();
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {
        // introAns.visible = true;
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();

    // introTitle.visible = false;
    // container.parent.removeChild(introTitle);

    container.parent.removeChild(introArrow);
    introArrow.visible = false;
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    container.parent.removeChild(introImg);
    introImg.visible = false;
    // // container.parent.removeChild(introImg);
    // // introImg.visible = false;
    container.parent.removeChild(introQuestxt);
    introQuestxt.visible = false;
    container.parent.removeChild(introChoice1);
    introChoice1.visible = false;
    container.parent.removeChild(introChoice2);
    introChoice2.visible = false;
    container.parent.removeChild(introChoice3);
    introChoice3.visible = false;

    container.parent.removeChild(introQuestxt1)
    introQuestxt1.visible = false;
    container.parent.removeChild(introQues1)
    introQues1.visible = false;
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}